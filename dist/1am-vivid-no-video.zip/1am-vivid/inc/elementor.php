<?php
/**
 * Elementor 연동
 *
 * - Elementor 편집기 왼쪽 위젯 목록에 "1AM" 카테고리: 영상 인트로, 맛 라인업, 상품 라인업, 디바이스,
 *   도매 가입 유도, 장점 카드, 구매 절차, FAQ, 맛 목록, 맛 슬라이더, 도매 가입 폼
 *   → 끌어다 놓고, 순서 바꾸고, 지우고, 오른쪽 패널에서 글자·이미지·영상 수정
 * - 상품·맛은 WooCommerce 에서 자동으로 읽어옴 (위젯에서 따로 입력하지 않음)
 * - 홈페이지를 Elementor 로 만들면 그 내용이, 아니면 테마 기본 홈 구성이 나옴
 * - 관리자 화면 버튼 한 번으로 지금의 홈 구성을 Elementor 페이지로 만들어 줌
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** 이 페이지를 Elementor 로 만들었는지 */
function oneam_is_builder_page( $post_id = 0 ) {
	$post_id = $post_id ? $post_id : get_the_ID();
	// 빈 Elementor 페이지는 "아직 안 만든 것"으로 봄 (홈이 하얗게 비지 않도록)
	return $post_id && 'builder' === get_post_meta( $post_id, '_elementor_edit_mode', true ) && did_action( 'elementor/loaded' ) && ! oneam_el_is_empty( $post_id );
}

/** Elementor 편집 화면(미리보기) 안인지 */
function oneam_is_builder_preview() {
	return isset( $_GET['elementor-preview'] ) // phpcs:ignore WordPress.Security.NonceVerification
		|| ( did_action( 'elementor/loaded' ) && class_exists( '\Elementor\Plugin' ) && isset( \Elementor\Plugin::$instance->preview ) && \Elementor\Plugin::$instance->preview->is_preview_mode() );
}

/** 편집 화면에서는 애니메이션 대신 완성된 모습을 그대로 보여줌 */
add_filter(
	'body_class',
	function ( $classes ) {
		if ( oneam_is_builder_preview() ) {
			$classes[] = 'is-builder';
		}
		return $classes;
	}
);

/* ---------------------------------------------------------------------------
 * 위젯 목록
 * ------------------------------------------------------------------------- */
function oneam_elementor_widgets() {
	$italic = 'Wrap a word in *stars* for the serif italic accent.';
	return array(
		'film'     => array(
			'title'    => 'Video intro',
			'icon'     => 'eicon-youtube',
			'part'     => 'film',
			'note'     => 'Full-screen brand video with a one-line caption and the wholesale button. Leave the video empty to use the one set in Customize › 1AM Settings.',
			'controls' => array(
				'oneam_intro_title'   => array( 'label' => 'Headline', 'type' => 'text', 'default' => oneam_opt( 'oneam_intro_title' ), 'description' => $italic ),
				'oneam_intro_text'    => array( 'label' => 'Caption', 'type' => 'text', 'default' => oneam_opt( 'oneam_intro_text' ) ),
				'oneam_video_mp4'     => array( 'label' => 'Video (MP4)', 'type' => 'video' ),
				'oneam_video_youtube' => array( 'label' => 'or YouTube link', 'type' => 'text' ),
				'oneam_video_poster'  => array( 'label' => 'Poster image', 'type' => 'image' ),
			),
			'style'    => array(
				array( 'tint', 'Dark tint strength', 'slider', '.film__tint', 'opacity' ),
				array( 'title_color', 'Headline colour', 'color', '.film__title', 'color' ),
				array( 'title_font', 'Headline font', 'typography', '.film__title' ),
				array( 'text_color', 'Caption colour', 'color', '.film__text', 'color' ),
				array( 'btn_bg', 'Button colour', 'color', '.film__btns .btn--solid', '--bg' ),
				array( 'btn_fg', 'Button text colour', 'color', '.film__btns .btn--solid', '--fg' ),
			),
		),
		'about'    => array(
			'title'    => 'Flavour line-up + About',
			'icon'     => 'eicon-slider-push',
			'part'     => 'about',
			'note'     => 'The devices come from your WooCommerce product variations (flavours) automatically.',
			'controls' => array(
				'eyebrow'           => array( 'label' => 'Small label', 'type' => 'text', 'default' => 'About 1AM' ),
				'oneam_about_title' => array( 'label' => 'Title', 'type' => 'textarea', 'default' => oneam_opt( 'oneam_about_title' ), 'description' => $italic ),
				'oneam_about_text'  => array( 'label' => 'Text', 'type' => 'textarea', 'default' => oneam_opt( 'oneam_about_text' ) ),
				'button'            => array( 'label' => 'Button text', 'type' => 'text', 'default' => 'About' ),
				'oneam_about_url'   => array( 'label' => 'Button link', 'type' => 'url', 'default' => '/about-us/' ),
				'bloom1'            => array( 'label' => 'Pastel circle colour 1', 'type' => 'color' ),
				'bloom2'            => array( 'label' => 'Pastel circle colour 2', 'type' => 'color' ),
				'bloom3'            => array( 'label' => 'Pastel circle colour 3', 'type' => 'color' ),
			),
			'style'    => array(
				array( 'bg', 'Background colour', 'color', '.about', 'background-color' ),
				array( 'eyebrow_color', 'Small label colour', 'color', '.about__intro .eyebrow', 'color' ),
				array( 'title_color', 'Title colour', 'color', '.about__title', 'color' ),
				array( 'title_font', 'Title font', 'typography', '.about__title' ),
				array( 'text_color', 'Text colour', 'color', '.about__text', 'color' ),
				array( 'btn_color', 'Button colour', 'color', '.about__intro .btn', 'color' ),
			),
		),
		'lineup'   => array(
			'title'    => 'Product line-up',
			'icon'     => 'eicon-posts-carousel',
			'part'     => 'lineup',
			'note'     => 'Shows your WooCommerce products as stacked cards (edit them in Products), or your own custom products below.',
			'controls' => array(
				'eyebrow' => array( 'label' => 'Small label', 'type' => 'text', 'default' => 'Product lineup' ),
				'title'   => array( 'label' => 'Title', 'type' => 'textarea', 'default' => "Three lines,\n*one standard.*", 'description' => 'One line per row. ' . $italic ),
				'items'   => array(
					'label'       => 'Custom products (optional)',
					'description' => 'Leave empty to show your WooCommerce products. Add items here to show your own instead.',
					'type'        => 'repeater',
					'fields'      => array(
						'name'  => array( 'label' => 'Name', 'type' => 'text' ),
						'tag'   => array( 'label' => 'Label (e.g. 2ml Disposable)', 'type' => 'text' ),
						'desc'  => array( 'label' => 'Description', 'type' => 'textarea' ),
						'image' => array( 'label' => 'Image (tall, transparent PNG/WebP)', 'type' => 'image' ),
						'c1'    => array( 'label' => 'Colour 1', 'type' => 'color' ),
						'c2'    => array( 'label' => 'Colour 2', 'type' => 'color' ),
						'link'  => array( 'label' => 'Link', 'type' => 'url' ),
						'soon'  => array( 'label' => 'Coming soon', 'type' => 'switch' ),
					),
					'default'     => array(),
				),
			),
			'style'    => array(
				array( 'bg', 'Background colour', 'color', '.plist', 'background-color' ),
				array( 'title_color', 'Title colour', 'color', '.plist__head .section-title', 'color' ),
				array( 'title_font', 'Title font', 'typography', '.plist__head .section-title' ),
				array( 'name_font', 'Product name font', 'typography', '.pitem__name' ),
				array( 'card_color', 'Card text colour', 'color', '.pitem', 'color' ),
				array( 'radius', 'Card corner radius', 'slider_px', '.pitem', 'border-radius' ),
			),
		),
		'device'   => array(
			'title'    => 'Device + specs',
			'icon'     => 'eicon-device-mobile',
			'part'     => 'device',
			'controls' => array(
				'oneam_device_title' => array( 'label' => 'Title', 'type' => 'textarea', 'default' => oneam_opt( 'oneam_device_title' ), 'description' => 'One line per row. ' . $italic ),
				'device_image'       => array( 'label' => 'Device image (optional)', 'type' => 'image', 'description' => 'Empty = the first 5 flavours from WooCommerce take turns.' ),
				'callouts'           => array(
					'label'   => 'Callouts',
					'type'    => 'repeater',
					'fields'  => array(
						'title' => array( 'label' => 'Title', 'type' => 'text' ),
						'text'  => array( 'label' => 'Text', 'type' => 'textarea' ),
					),
					'default' => array(
						array( 'title' => 'Crystal shell', 'text' => 'A clear crystal body shows the colour core inside.' ),
						array( 'title' => 'Gradient core', 'text' => 'Each flavour has its own gradient.' ),
						array( 'title' => 'Slim HYBRID', 'text' => 'A slim body that sits easily in the hand.' ),
						array( 'title' => 'Soft mouthpiece', 'text' => 'A smooth, rounded mouthpiece.' ),
					),
				),
				'specs'              => array(
					'label'   => 'Numbers',
					'type'    => 'repeater',
					'fields'  => array(
						'num'   => array( 'label' => 'Number', 'type' => 'text' ),
						'label' => array( 'label' => 'Label', 'type' => 'text' ),
					),
					'default' => array(
						array( 'num' => oneam_opt( 'oneam_spec_1_num' ), 'label' => oneam_opt( 'oneam_spec_1_label' ) ),
						array( 'num' => oneam_opt( 'oneam_spec_2_num' ), 'label' => oneam_opt( 'oneam_spec_2_label' ) ),
						array( 'num' => oneam_opt( 'oneam_spec_3_num' ), 'label' => oneam_opt( 'oneam_spec_3_label' ) ),
					),
				),
			),
			'style'    => array(
				array( 'c1', 'Glow colour 1', 'color', '.device', '--c1' ),
				array( 'c2', 'Glow colour 2', 'color', '.device', '--c2' ),
				array( 'bg', 'Background colour', 'color', '.device', 'background-color' ),
				array( 'text_color', 'Text colour', 'color', '.device', 'color' ),
				array( 'title_font', 'Title font', 'typography', '.device__title' ),
			),
		),
		'cta'      => array(
			'title'    => 'Wholesale call to action',
			'icon'     => 'eicon-call-to-action',
			'part'     => 'cta',
			'note'     => 'The button changes by visitor: Apply / Application under review / Shop wholesale.',
			'controls' => array(
				'oneam_cta_title' => array( 'label' => 'Title', 'type' => 'text', 'default' => oneam_opt( 'oneam_cta_title' ), 'description' => $italic ),
				'oneam_cta_text'  => array( 'label' => 'Text', 'type' => 'textarea', 'default' => oneam_opt( 'oneam_cta_text' ) ),
				'note'            => array( 'label' => 'Small print', 'type' => 'text', 'default' => 'Retailers only · ' . (int) oneam_opt( 'oneam_min_age' ) . '+ · Canada' ),
				'logo_on'         => array( 'label' => 'Show "1AM" as the logo', 'type' => 'switch', 'default' => 'yes' ),
				'logo'            => array( 'label' => 'Logo image (optional)', 'type' => 'image', 'description' => 'Empty = the site logo.' ),
			),
			'style'    => array(
				array( 'c1', 'Fill colour 1', 'color', '.cta', '--c1' ),
				array( 'c2', 'Fill colour 2', 'color', '.cta', '--c2' ),
				array( 'bg', 'Background colour', 'color', '.cta', 'background-color' ),
				array( 'stroke', 'Title outline colour', 'color', '.cta__title', '-webkit-text-stroke-color' ),
				array( 'title_font', 'Title font', 'typography', '.cta__title' ),
				array( 'text_color', 'Text colour', 'color', '.cta__text', 'color' ),
			),
		),
		'benefits' => array(
			'title'    => 'Benefit cards',
			'icon'     => 'eicon-gallery-grid',
			'part'     => 'benefits',
			'controls' => array(
				'eyebrow' => array( 'label' => 'Small label', 'type' => 'text', 'default' => 'For retailers' ),
				'title'   => array( 'label' => 'Title', 'type' => 'textarea', 'default' => "Why stock\n*1AM*?", 'description' => 'One line per row. ' . $italic ),
				'items'   => array(
					'label'   => 'Cards',
					'type'    => 'repeater',
					'fields'  => array(
						'title' => array( 'label' => 'Title', 'type' => 'text' ),
						'text'  => array( 'label' => 'Text', 'type' => 'textarea' ),
						'c1'    => array( 'label' => 'Colour 1', 'type' => 'color' ),
						'c2'    => array( 'label' => 'Colour 2', 'type' => 'color' ),
					),
					'default' => array(
						array( 'title' => 'Wholesale pricing', 'text' => 'Trade pricing for approved accounts, visible as soon as you log in.', 'c1' => '#FF2E4D', 'c2' => '#FFB321' ),
						array( 'title' => 'Approved retailers only', 'text' => 'We only work with stores whose business documents we have verified.', 'c1' => '#8A3FFC', 'c2' => '#1E5BFF' ),
						array( 'title' => 'Ships where it\'s allowed', 'text' => 'Orders ship only to provinces where our products can be sold.', 'c1' => '#00C2A8', 'c2' => '#16C75A' ),
						array( 'title' => 'Clear product info', 'text' => 'Specs, flavours and product details in one place.', 'c1' => '#FFD60A', 'c2' => '#FF8A4D' ),
					),
				),
			),
			'style'    => array(
				array( 'bg', 'Background colour', 'color', '.benefits', 'background-color' ),
				array( 'title_color', 'Title colour', 'color', '.benefits .section-title', 'color' ),
				array( 'title_font', 'Title font', 'typography', '.benefits .section-title' ),
				array( 'card_bg', 'Card colour', 'color', '.benefit', 'background-color' ),
				array( 'card_color', 'Card text colour', 'color', '.benefit', 'color' ),
			),
		),
		'steps'    => array(
			'title'    => 'How to order steps',
			'icon'     => 'eicon-number-field',
			'part'     => 'steps',
			'controls' => array(
				'eyebrow' => array( 'label' => 'Small label', 'type' => 'text', 'default' => 'How to order' ),
				'title'   => array( 'label' => 'Title', 'type' => 'textarea', 'default' => "Three steps\n*to your first* order", 'description' => 'One line per row. ' . $italic ),
				'items'   => array(
					'label'   => 'Steps',
					'type'    => 'repeater',
					'fields'  => array(
						'title' => array( 'label' => 'Title', 'type' => 'text' ),
						'text'  => array( 'label' => 'Text', 'type' => 'textarea' ),
					),
					'default' => array(
						array( 'title' => 'Apply', 'text' => 'Submit the wholesale application with your business documents (business registration and retail licence).' ),
						array( 'title' => 'Get approved', 'text' => 'Our team reviews your documents and emails you once your account is approved.' ),
						array( 'title' => 'Order', 'text' => 'Log in to the private shop, see wholesale pricing and place your order.' ),
					),
				),
			),
			'style'    => array(
				array( 'bg', 'Background colour', 'color', '.steps', 'background-color' ),
				array( 'text_color', 'Text colour', 'color', '.steps', 'color' ),
				array( 'title_font', 'Title font', 'typography', '.steps .section-title' ),
			),
		),
		'faq'      => array(
			'title'    => 'FAQ',
			'icon'     => 'eicon-accordion',
			'part'     => 'faq',
			'controls' => array(
				'eyebrow' => array( 'label' => 'Small label', 'type' => 'text', 'default' => 'FAQ' ),
				'title'   => array( 'label' => 'Title', 'type' => 'textarea', 'default' => "Questions,\n*answered.*", 'description' => 'One line per row. ' . $italic ),
				'items'   => array(
					'label'   => 'Questions',
					'type'    => 'repeater',
					'fields'  => array(
						'q' => array( 'label' => 'Question', 'type' => 'text' ),
						'a' => array( 'label' => 'Answer', 'type' => 'textarea' ),
					),
					'default' => array(
						array( 'q' => 'Who can buy from 1AM?', 'a' => 'Only Canadian retailers approved after a business document check can order. We do not sell to consumers.' ),
						array( 'q' => 'How long does approval take?', 'a' => 'We review applications within 1–2 business days and email you once you are approved.' ),
						array( 'q' => 'Is there a minimum order?', 'a' => 'Minimum order quantities and pricing are shown in the wholesale shop after approval.' ),
						array( 'q' => 'Where do you ship?', 'a' => 'We ship only to provinces where our products can be sold. Other addresses cannot be selected at checkout.' ),
						array( 'q' => 'How do I pay?', 'a' => 'Pay by Interac e-Transfer or bank transfer.' ),
					),
				),
			),
			'style'    => array(
				array( 'bg', 'Background colour', 'color', '.faq', 'background-color' ),
				array( 'title_color', 'Title colour', 'color', '.faq .section-title', 'color' ),
				array( 'title_font', 'Title font', 'typography', '.faq .section-title' ),
				array( 'q_color', 'Question colour', 'color', '.faq__item summary', 'color' ),
			),
		),
		'flavors'  => array(
			'title'    => 'Flavour grid',
			'icon'     => 'eicon-gallery-masonry',
			'part'     => 'flavors',
			'note'     => 'Flavour cards with category filter, from your WooCommerce variations.',
			'controls' => array(
				'title' => array( 'label' => 'Title', 'type' => 'text', 'default' => 'Slim HYBRID', 'arg' => true ),
				'line'  => array( 'label' => 'Only this product (slug, optional)', 'type' => 'text', 'default' => '', 'arg' => true, 'description' => 'e.g. slim-hybrid. Empty = all flavours.' ),
			),
			'style'    => array(
				array( 'bg', 'Background colour', 'color', '.flavors', 'background-color' ),
				array( 'title_font', 'Title font', 'typography', '.flavors .section-title' ),
			),
		),
		'hero'     => array(
			'title'    => 'Flavour slider',
			'icon'     => 'eicon-slides',
			'part'     => 'hero',
			'note'     => 'The big colour slider used at the top of the Slim HYBRID product page.',
			'controls' => array(
				'title'  => array( 'label' => 'Title', 'type' => 'textarea', 'default' => "Slim\nHYBRID.", 'arg' => true ),
				'kicker' => array( 'label' => 'Small label', 'type' => 'text', 'default' => '', 'arg' => true, 'description' => 'Empty = "2ml Disposable · 15 flavours"' ),
				'line'   => array( 'label' => 'Product (slug)', 'type' => 'text', 'default' => 'slim-hybrid', 'arg' => true ),
			),
		),
		'signup'   => array(
			'title'    => 'Wholesale application form',
			'icon'     => 'eicon-form-horizontal',
			'part'     => '',
			'note'     => 'The sign-up form. Applications appear in Users › Pending wholesale.',
			'controls' => array(),
		),
	);
}

/* ---------------------------------------------------------------------------
 * Elementor 에 등록
 * ------------------------------------------------------------------------- */
add_action(
	'elementor/elements/categories_registered',
	function ( $manager ) {
		$manager->add_category( 'oneam', array( 'title' => '1AM', 'icon' => 'fa fa-plug' ) );
	}
);

add_action(
	'elementor/widgets/register',
	function ( $widgets ) {
		require_once get_template_directory() . '/inc/elementor-widget.php';
		foreach ( array_keys( oneam_elementor_widgets() ) as $key ) {
			$class = 'OneAM_El_' . ucfirst( $key );
			if ( class_exists( $class ) ) {
				$widgets->register( new $class() );
			}
		}
	}
);

/** 편집기에서도 테마 스타일 · 폰트 */
add_action(
	'elementor/preview/enqueue_styles',
	function () {
		wp_enqueue_style( 'oneam-main' );
	}
);

/* ---------------------------------------------------------------------------
 * 홈 구성을 Elementor 페이지로 만들기 (관리자 버튼)
 * ------------------------------------------------------------------------- */
function oneam_el_id() {
	return substr( md5( wp_generate_password( 12, false ) ), 0, 7 );
}

/** 위젯 하나를 꽉 찬 섹션에 담은 Elementor 데이터 */
function oneam_el_uses_containers() {
	return class_exists( '\Elementor\Plugin' ) && isset( \Elementor\Plugin::$instance->experiments )
		&& \Elementor\Plugin::$instance->experiments->is_feature_active( 'container' );
}

function oneam_el_section( $widget, $settings = array() ) {
	$w = array(
		'id'         => oneam_el_id(),
		'elType'     => 'widget',
		'widgetType' => 'oneam-' . $widget,
		'settings'   => (object) $settings,
		'elements'   => array(),
	);
	// 새 Elementor (Flexbox 컨테이너)
	if ( oneam_el_uses_containers() ) {
		return array(
			'id'       => oneam_el_id(),
			'elType'   => 'container',
			'settings' => array(
				'content_width' => 'full',
				'flex_gap'      => array( 'size' => 0, 'column' => '0', 'row' => '0', 'unit' => 'px', 'isLinked' => true ),
				'padding'       => array( 'unit' => 'px', 'top' => '0', 'right' => '0', 'bottom' => '0', 'left' => '0', 'isLinked' => true ),
			),
			'elements' => array( $w ),
			'isInner'  => false,
		);
	}
	// 예전 Elementor (섹션 + 칼럼)
	return array(
		'id'       => oneam_el_id(),
		'elType'   => 'section',
		'settings' => array( 'layout' => 'full_width', 'gap' => 'no', 'stretch_section' => 'section-stretched' ),
		'elements' => array(
			array(
				'id'       => oneam_el_id(),
				'elType'   => 'column',
				'settings' => array( '_column_size' => 100 ),
				'elements' => array(
					array(
						'id'         => oneam_el_id(),
						'elType'     => 'widget',
						'widgetType' => 'oneam-' . $widget,
						'settings'   => (object) $settings,
						'elements'   => array(),
					),
				),
				'isInner'  => false,
			),
		),
		'isInner'  => false,
	);
}

function oneam_home_layout() {
	return array_map( 'oneam_el_section', array( 'film', 'about', 'lineup', 'device', 'cta' ) );
}

/** 홈이 "최신 글 페이지"로도 지정돼 있으면 해제 (같은 페이지면 Elementor 로 편집할 수 없음) */
function oneam_fix_posts_page() {
	$front = (int) get_option( 'page_on_front' );
	if ( $front && 'page' === get_option( 'show_on_front' ) && (int) get_option( 'page_for_posts' ) === $front ) {
		update_option( 'page_for_posts', 0 );
	}
}
add_action( 'admin_init', 'oneam_fix_posts_page' );
add_filter(
	'option_page_for_posts',
	function ( $v ) {
		return ( (int) $v && (int) $v === (int) get_option( 'page_on_front' ) && 'page' === get_option( 'show_on_front' ) ) ? 0 : $v;
	}
);

/** Elementor 데이터가 비어 있는지 */
function oneam_el_is_empty( $id ) {
	$data = get_post_meta( $id, '_elementor_data', true );
	if ( is_string( $data ) ) {
		$data = json_decode( $data, true );
	}
	return empty( $data );
}

/** 페이지에 1AM 홈 구성을 채워 넣음 */
function oneam_fill_home( $id ) {
	update_post_meta( $id, '_elementor_edit_mode', 'builder' );
	update_post_meta( $id, '_elementor_template_type', 'wp-page' );
	if ( defined( 'ELEMENTOR_VERSION' ) ) {
		update_post_meta( $id, '_elementor_version', ELEMENTOR_VERSION );
	}
	update_post_meta( $id, '_elementor_data', wp_slash( wp_json_encode( oneam_home_layout() ) ) );
	delete_post_meta( $id, '_elementor_css' );
	if ( class_exists( '\Elementor\Plugin' ) && isset( \Elementor\Plugin::$instance->files_manager ) ) {
		\Elementor\Plugin::$instance->files_manager->clear_cache();
	}
}

/** 홈 페이지 (없으면 만들어서 홈으로 지정) */
function oneam_home_page_id( $create = false ) {
	$id = 'page' === get_option( 'show_on_front' ) ? (int) get_option( 'page_on_front' ) : 0;
	if ( ! $id && $create ) {
		$id = wp_insert_post( array( 'post_type' => 'page', 'post_status' => 'publish', 'post_title' => 'Home' ) );
		update_option( 'show_on_front', 'page' );
		update_option( 'page_on_front', $id );
	}
	oneam_fix_posts_page();
	return $id;
}

/** 버튼: 홈을 1AM 구성으로 (다시) 만들기 */
add_action(
	'admin_post_oneam_build_home',
	function () {
		check_admin_referer( 'oneam_build_home' );
		if ( ! current_user_can( 'edit_pages' ) || ! did_action( 'elementor/loaded' ) ) {
			wp_die( 'Not allowed.' );
		}
		$id = oneam_home_page_id( true );
		oneam_fill_home( $id );
		wp_safe_redirect( admin_url( 'post.php?post=' . $id . '&action=elementor' ) );
		exit;
	}
);

/** 빈 홈을 Elementor 로 열면 1AM 구성을 자동으로 넣어 줌 (빈 화면 대신) */
add_action(
	'admin_action_elementor',
	function () {
		$id = isset( $_GET['post'] ) ? absint( $_GET['post'] ) : 0; // phpcs:ignore WordPress.Security.NonceVerification
		if ( $id && current_user_can( 'edit_post', $id ) && $id === oneam_home_page_id() && oneam_el_is_empty( $id ) ) {
			oneam_fill_home( $id );
		}
	},
	1
);

/** 버튼: 페이지 목록 · 대시보드 · 홈 편집 화면 상단 */
add_action(
	'admin_notices',
	function () {
		if ( ! did_action( 'elementor/loaded' ) || ! current_user_can( 'edit_pages' ) ) {
			return;
		}
		$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
		if ( ! $screen || ! in_array( $screen->id, array( 'dashboard', 'edit-page', 'page' ), true ) ) {
			return;
		}
		$home  = oneam_home_page_id();
		$build = wp_nonce_url( admin_url( 'admin-post.php?action=oneam_build_home' ), 'oneam_build_home' );
		if ( $home && oneam_is_builder_page( $home ) && ! oneam_el_is_empty( $home ) ) {
			if ( 'dashboard' === $screen->id ) {
				return;
			}
			printf(
				'<div class="notice notice-info"><p><strong>1AM ' . ONEAM_VERSION . ':</strong> Your homepage is built with Elementor. <a class="button button-primary" href="%1$s">Edit homepage in Elementor</a> <a class="button" href="%2$s" onclick="return confirm(\'Replace the homepage with the original 1AM sections? Your Elementor changes on the homepage will be lost.\');">Reset to 1AM layout</a></p></div>',
				esc_url( admin_url( 'post.php?post=' . $home . '&action=elementor' ) ),
				esc_url( $build )
			);
			return;
		}
		printf(
			'<div class="notice notice-info"><p><strong>1AM ' . ONEAM_VERSION . ':</strong> Edit the homepage visually in Elementor — the current sections (video, flavour line-up, products, device, call to action) are added as 1AM widgets you can move, delete and edit. <a class="button button-primary" href="%s">Build homepage in Elementor</a></p></div>',
			esc_url( $build )
		);
	}
);

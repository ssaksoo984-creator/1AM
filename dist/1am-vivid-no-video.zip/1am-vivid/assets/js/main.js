/* ==========================================================================
   1AM Vivid — main.js
   GSAP + ScrollTrigger + Lenis
   ========================================================================== */
(function () {
	'use strict';

	var cfg = window.ONEAM || { ageGate: true };
	var gsap = window.gsap;
	var ST = window.ScrollTrigger;
	var $ = function (s, c) { return (c || document).querySelector(s); };
	var $$ = function (s, c) { return Array.prototype.slice.call((c || document).querySelectorAll(s)); };
	var body = document.body;
	var reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
	var lite = !!cfg.lite; // 쇼핑몰(장바구니·결제·내 계정) 페이지
	// Elementor 편집 화면: 스크롤 애니메이션 없이 완성된 모습만 (CSS .is-builder)
	var builder = !!cfg.builder || body.classList.contains('elementor-editor-active');
	if (builder) {
		body.classList.add('is-builder');
		body.classList.remove('is-loading');
		return;
	}
	var finePointer = window.matchMedia('(hover: hover) and (pointer: fine)').matches;

	if (!gsap) { body.classList.remove('is-loading'); return; }
	gsap.registerPlugin(ST);

	var store = {
		get: function (k) { try { return window.localStorage.getItem(k); } catch (e) { return null; } },
		set: function (k, v) { try { window.localStorage.setItem(k, v); } catch (e) { /* noop */ } }
	};

	/* ---------------------------------------------------------------- Lenis */
	var lenis = null;
	if (window.Lenis && !reduce && !lite) {
		lenis = new window.Lenis({ lerp: 0.1, smoothWheel: true });
		lenis.on('scroll', ST.update);
		gsap.ticker.add(function (t) { lenis.raf(t * 1000); });
		gsap.ticker.lagSmoothing(0);
	}
	function lock(on) {
		body.classList.toggle('is-locked', on);
		if (lenis) { on ? lenis.stop() : lenis.start(); }
	}

	// 앵커 링크 부드럽게
	$$('a[href*="#"]').forEach(function (a) {
		a.addEventListener('click', function (e) {
			var url = new URL(a.href, location.href);
			if (url.pathname !== location.pathname || !url.hash) return;
			var target = $(url.hash);
			if (!target) return;
			e.preventDefault();
			closeMenu();
			if (lenis) lenis.scrollTo(target, { offset: 0, duration: 1.4 });
			else target.scrollIntoView({ behavior: reduce ? 'auto' : 'smooth' });
		});
	});

	/* ------------------------------------------------------------- Age gate */
	function ageGate() {
		return new Promise(function (resolve) {
			var gate = $('#agegate');
			if (!gate || !cfg.ageGate || store.get('oneam_age') === '1') { resolve(); return; }
			gate.hidden = false;
			lock(true);
			gsap.from('.agegate__box', { y: 60, opacity: 0, duration: 1, ease: 'expo.out' });
			gate.addEventListener('click', function (e) {
				var btn = e.target.closest('[data-age]');
				if (!btn) return;
				if (btn.dataset.age === 'no') {
					gate.classList.add('is-denied');
					$('.agegate__txt', gate).textContent = 'Sorry, this site is for adults only.';
					gsap.fromTo('.agegate__box', { x: -10 }, { x: 0, duration: .5, ease: 'elastic.out(1, .3)' });
					return;
				}
				store.set('oneam_age', '1');
				gsap.to(gate, {
					clipPath: 'inset(0 0 100% 0)', duration: .9, ease: 'expo.inOut',
					onComplete: function () { gate.remove(); lock(false); resolve(); }
				});
			});
		});
	}

	/* --------------------------------------------------------------- Loader */
	function loader() {
		return new Promise(function (resolve) {
			var el = $('#loader');
			if (!el || reduce) { resolve(); return; }
			var num = $('#loader-num');
			var o = { m: 0 };
			var tl = gsap.timeline({ onComplete: resolve });
			tl.from('.loader__logo', { scale: .6, opacity: 0, duration: .8, ease: 'expo.out' })
				.to(o, {
					m: 60, duration: 1.1, ease: 'power2.inOut',
					onUpdate: function () {
						var m = Math.round(o.m);
						num.textContent = (m === 60 ? '01:00' : '00:' + String(m).padStart(2, '0')) + ' AM';
					}
				}, '<.1')
				.to('.loader__inner', { y: -40, opacity: 0, duration: .5, ease: 'power3.in' }, '+=.15')
				.to('.loader__bg', { clipPath: 'circle(0% at 50% 50%)', duration: 1, ease: 'expo.inOut' }, '-=.2');
		});
	}

	/* --------------------------------------------------------------- Header */
	var header = $('#site-header');
	var lastY = 0;
	function onScrollHeader(y) {
		if (!header || body.classList.contains('nav-open')) return;
		header.classList.toggle('is-hidden', y > lastY && y > 200);
		lastY = y;
	}
	if (lenis) lenis.on('scroll', function (l) { onScrollHeader(l.scroll); });
	else window.addEventListener('scroll', function () { onScrollHeader(window.scrollY); }, { passive: true });

	/* ----------------------------------------------------------------- Menu */
	var menuBtn = $('#menu-btn');
	function closeMenu() {
		if (!body.classList.contains('nav-open')) return;
		body.classList.remove('nav-open');
		menuBtn && menuBtn.setAttribute('aria-expanded', 'false');
	}
	if (menuBtn) {
		menuBtn.addEventListener('click', function () {
			if (body.classList.contains('nav-open')) { closeMenu(); return; }
			body.classList.add('nav-open');
			menuBtn.setAttribute('aria-expanded', 'true');
		});
		document.addEventListener('keydown', function (e) { if (e.key === 'Escape') closeMenu(); });
	}

	/* --------------------------------------------------------------- Cursor */
	if (finePointer && !reduce && !lite) {
		var cursor = $('.cursor');
		var label = $('.cursor__label');
		var xTo = gsap.quickTo(cursor, 'x', { duration: .35, ease: 'power3' });
		var yTo = gsap.quickTo(cursor, 'y', { duration: .35, ease: 'power3' });
		window.addEventListener('pointermove', function (e) { xTo(e.clientX); yTo(e.clientY); });
		document.addEventListener('pointerover', function (e) {
			var t = e.target.closest('[data-cursor], a, button');
			cursor.classList.toggle('is-hover', !!t);
			var lbl = t && t.closest('[data-cursor]');
			cursor.classList.toggle('has-label', !!lbl);
			label.textContent = lbl ? lbl.dataset.cursor : '';
		});

		// 마그네틱 버튼
		$$('[data-magnetic]').forEach(function (el) {
			var mx = gsap.quickTo(el, 'x', { duration: .6, ease: 'elastic.out(1, .4)' });
			var my = gsap.quickTo(el, 'y', { duration: .6, ease: 'elastic.out(1, .4)' });
			el.addEventListener('pointermove', function (e) {
				var r = el.getBoundingClientRect();
				mx((e.clientX - r.left - r.width / 2) * .35);
				my((e.clientY - r.top - r.height / 2) * .35);
			});
			el.addEventListener('pointerleave', function () { mx(0); my(0); });
		});
	}

	/* ----------------------------------------------------------------- Hero */
	function setBodyColors(c1, c2, dur) {
		gsap.to(body, { '--c1': c1, '--c2': c2, duration: dur == null ? 1 : dur, ease: 'power2.out', overwrite: 'auto' });
	}

	function hero() {
		var root = $('#hero');
		if (!root) return { intro: function () {} };
		var devices = $$('.hero__device', root);
		var names = $$('.hero__name', root);
		var dots = $$('.hero__dots button', root);
		var idxEl = $('#hero-idx');
		var nameEl = $('#hero-flavor');
		var descEl = $('#hero-desc');
		var bar = $('.hero__progress span', root);
		var cur = 0;
		var busy = false;
		var DURATION = 5;
		var autoplay;

		// 첫 번째 외의 디바이스는 GSAP 가 제어
		devices.forEach(function (d, i) { if (i) gsap.set(d, { opacity: 0 }); });
		gsap.set(devices[0], { opacity: 1, rotate: -6, y: 0, scale: 1 });

		function go(next, dir) {
			if (busy || next === cur) return;
			busy = true;
			dir = dir || (next > cur ? 1 : -1);
			var from = devices[cur];
			var to = devices[next];
			var d = to.dataset;

			setBodyColors(d.c1, d.c2, 1);

			gsap.to(from, { y: -120 * dir, rotate: -6 + 30 * dir, opacity: 0, scale: .85, duration: .7, ease: 'power3.in' });
			gsap.fromTo(to,
				{ y: 160 * dir, rotate: -6 - 40 * dir, opacity: 0, scale: .8 },
				{ y: 0, rotate: -6, opacity: 1, scale: 1, duration: 1.2, delay: .35, ease: 'elastic.out(1, .6)', onComplete: function () { busy = false; } });

			names[cur].classList.remove('is-active');
			names[cur].classList.add('is-leaving');
			(function (n) { setTimeout(function () { n.classList.remove('is-leaving'); }, 900); })(names[cur]);
			names[next].classList.add('is-active');

			dots.forEach(function (b, i) { b.classList.toggle('is-active', i === next); });

			gsap.to([nameEl, descEl], {
				y: -14, opacity: 0, duration: .25, ease: 'power2.in', onComplete: function () {
					nameEl.textContent = d.name;
					descEl.textContent = d.desc;
					idxEl.textContent = String(next + 1).padStart(2, '0');
					gsap.fromTo([nameEl, descEl], { y: 14, opacity: 0 }, { y: 0, opacity: 1, duration: .5, stagger: .06, ease: 'power3.out' });
				}
			});

			cur = next;
			restart();
		}
		function nextSlide() { go((cur + 1) % devices.length, 1); }
		function prevSlide() { go((cur - 1 + devices.length) % devices.length, -1); }

		function restart() {
			if (autoplay) autoplay.kill();
			autoplay = gsap.fromTo(bar, { scaleX: 0 }, { scaleX: 1, duration: DURATION, ease: 'none', onComplete: nextSlide });
		}

		$$('[data-hero]', root).forEach(function (b) {
			b.addEventListener('click', function () { b.dataset.hero === 'next' ? nextSlide() : prevSlide(); });
		});
		dots.forEach(function (b) { b.addEventListener('click', function () { go(+b.dataset.idx); }); });
		root.addEventListener('keydown', function (e) {
			if (e.key === 'ArrowRight') nextSlide();
			if (e.key === 'ArrowLeft') prevSlide();
		});

		// 스와이프 / 드래그
		var sx = null;
		root.addEventListener('pointerdown', function (e) { if (!e.target.closest('button, a')) sx = e.clientX; });
		window.addEventListener('pointerup', function (e) {
			if (sx === null) return;
			var dx = e.clientX - sx;
			sx = null;
			if (Math.abs(dx) > 50) (dx < 0 ? nextSlide : prevSlide)();
		});

		// 마우스 패럴랙스
		if (finePointer && !reduce) {
			var stage = $('.hero__stage', root);
			var rx = gsap.quickTo(stage, 'rotationY', { duration: .8, ease: 'power3' });
			var ry = gsap.quickTo(stage, 'rotationX', { duration: .8, ease: 'power3' });
			var sxTo = gsap.quickTo(stage, 'x', { duration: 1, ease: 'power3' });
			var orbs = $$('.orb', root);
			root.addEventListener('pointermove', function (e) {
				var px = e.clientX / window.innerWidth - .5;
				var py = e.clientY / window.innerHeight - .5;
				rx(px * 30); ry(-py * 20); sxTo(px * 40);
				orbs.forEach(function (o, i) { gsap.to(o, { x: px * (40 + i * 30), y: py * (40 + i * 30), duration: 1.2, ease: 'power3', overwrite: 'auto' }); });
			});
		}

		// 스크롤 시 히어로 빠져나가기
		gsap.timeline({ scrollTrigger: { trigger: root, start: 'top top', end: 'bottom top', scrub: true } })
			.to('.hero__names', { yPercent: 30, scale: 1.2 }, 0)
			.to('.hero__stage', { y: -120, scale: .9 }, 0)
			.to('.hero__copy, .hero__ctrl', { y: -80, opacity: 0 }, 0);

		// 화면 밖이면 자동재생 일시정지
		ST.create({ trigger: root, start: 'top bottom', end: 'bottom top', onToggle: function (s) { autoplay && (s.isActive ? autoplay.resume() : autoplay.pause()); } });

		return {
			intro: function () {
				var tl = gsap.timeline({ onComplete: restart });
				tl.from('.hero__title .line > span', { yPercent: 110, duration: 1.1, stagger: .1, ease: 'expo.out' })
					.from('.hero__kicker', { y: 20, opacity: 0, duration: .8, ease: 'expo.out' }, 0.1)
					.from(devices[0], { y: 300, rotate: 30, opacity: 0, duration: 1.6, ease: 'elastic.out(1, .7)' }, 0)
					.from('.hero__ctrl > *, .hero__dots, .hero__scroll', { y: 30, opacity: 0, duration: .8, stagger: .06, ease: 'expo.out' }, .3)
					.from('.orb', { scale: 0, duration: 1.2, stagger: .1, ease: 'back.out(2)' }, .2);
			}
		};
	}

	/* ------------------------------------------------- Product line-up */
	// 카드가 세로로 쌓이는 구조 (CSS sticky) — 스크롤은 그대로, 들어올 때 한 번만 등장
	function lineup() {
		$$('.pitem').forEach(function (card) {
			var img = $('.pitem__img, .ghost', card);
			if (img) gsap.from(img, { y: 120, opacity: 0, duration: 1.2, ease: 'expo.out', scrollTrigger: { trigger: card, start: 'top 80%', once: true } });
			gsap.from($$('.pitem__text > *', card), { y: 30, opacity: 0, duration: .8, stagger: .06, ease: 'expo.out', scrollTrigger: { trigger: card, start: 'top 75%', once: true } });
		});
	}

	/* -------------------------------------------------------------- Flavors */
	function flavors() {
		var cards = $$('.card');
		if (!cards.length) return;

		gsap.from(cards, {
			y: 80, opacity: 0, duration: 1, stagger: { each: .05, grid: 'auto', from: 'start' }, ease: 'expo.out',
			scrollTrigger: { trigger: '.grid', start: 'top 85%' }
		});

		$$('.chip').forEach(function (chip) {
			chip.addEventListener('click', function () {
				$$('.chip').forEach(function (c) { c.classList.toggle('is-active', c === chip); });
				var f = chip.dataset.filter;
				gsap.to(cards, {
					opacity: 0, y: 20, duration: .25, stagger: .015, ease: 'power2.in', onComplete: function () {
						var shown = cards.filter(function (c) {
							var on = f === 'all' || c.dataset.cat === f;
							c.classList.toggle('is-hidden', !on);
							return on;
						});
						gsap.fromTo(shown, { opacity: 0, y: 40, scale: .95 }, { opacity: 1, y: 0, scale: 1, duration: .7, stagger: .04, ease: 'expo.out' });
						ST.refresh();
					}
				});
			});
		});

		// 틸트 + 컬러 채움 시작점
		cards.forEach(function (card) {
			var a = $('a', card);
			a.addEventListener('pointerenter', function (e) { setOrigin(e); });
			a.addEventListener('pointerleave', function (e) {
				setOrigin(e);
				gsap.to(a, { rotationX: 0, rotationY: 0, duration: .8, ease: 'elastic.out(1, .5)' });
			});
			if (finePointer && !reduce) {
				a.addEventListener('pointermove', function (e) {
					var r = a.getBoundingClientRect();
					var px = (e.clientX - r.left) / r.width - .5;
					var py = (e.clientY - r.top) / r.height - .5;
					gsap.to(a, { rotationY: px * 14, rotationX: -py * 14, duration: .5, ease: 'power3' });
				});
			}
			function setOrigin(e) {
				var r = a.getBoundingClientRect();
				a.style.setProperty('--mx', ((e.clientX - r.left) / r.width * 100) + '%');
				a.style.setProperty('--my', ((e.clientY - r.top) / r.height * 100) + '%');
			}
		});
	}

	/* --------------------------------------------------------------- Device */
	// 스크롤을 붙잡지 않음: 들어올 때 한 번 등장하고, 화면에 보이는 동안 맛이 저절로 바뀜
	function device() {
		var root = $('#device');
		if (!root) return;
		var imgs = $$('.device__stack img', root);
		gsap.timeline({ scrollTrigger: { trigger: root, start: 'top 65%', once: true } })
			.from($$('.device__title .line > span', root), { yPercent: 110, stagger: .1, duration: .9, ease: 'expo.out' }, 0)
			.from($('.device__stack', root), { scale: .6, rotate: -25, y: 120, opacity: 0, duration: 1.2, ease: 'expo.out' }, .1)
			.from($$('.callout', root), { opacity: 0, x: function (i) { return i % 2 ? 50 : -50; }, stagger: .12, duration: .8, ease: 'expo.out' }, .4);
		if (imgs.length < 2) return;
		var cur = 0, timer = null;
		function next() {
			var a = imgs[cur];
			cur = (cur + 1) % imgs.length;
			var b = imgs[cur];
			gsap.to(a, { opacity: 0, rotate: 12, duration: .7, ease: 'power2.inOut' });
			gsap.fromTo(b, { opacity: 0, rotate: -12 }, { opacity: 1, rotate: 0, duration: .7, ease: 'power2.inOut' });
			gsap.to(root, { '--c1': b.dataset.c1, '--c2': b.dataset.c2, duration: .7 });
		}
		ST.create({
			trigger: root, start: 'top bottom', end: 'bottom top',
			onToggle: function (s) { clearInterval(timer); if (s.isActive) timer = setInterval(next, 2200); }
		});
	}

	/* ------------------------------------------------------------------ CTA */
	function cta() {
		var root = $('#wholesale');
		if (!root) return;
		var imgs = $$('.cta__fan img', root);
		gsap.fromTo(imgs,
			{ rotate: 0, x: 0, y: 80 },
			{
				rotate: function (i, el) { return +getComputedStyle(el).getPropertyValue('--o') * 11; },
				x: function (i, el) { return +getComputedStyle(el).getPropertyValue('--o') * Math.min(60, window.innerWidth / 18); },
				y: function (i, el) { return Math.abs(+getComputedStyle(el).getPropertyValue('--o')) * 14; },
				ease: 'none',
				scrollTrigger: { trigger: root, start: 'top 80%', end: 'center center', scrub: 1 }
			});
		var title = $('[data-fill]', root);
		gsap.fromTo(title, { '--fill': '0%' }, { '--fill': '100%', ease: 'none', scrollTrigger: { trigger: title, start: 'top 85%', end: 'bottom 45%', scrub: true } });
	}

	/* --------------------------------------------------------- 공통 리빌 */
	function reveals() {
		$$('[data-reveal]').forEach(function (el) {
			gsap.from($$('.line > span', el), { yPercent: 110, duration: 1.1, stagger: .1, ease: 'expo.out', scrollTrigger: { trigger: el, start: 'top 85%' } });
		});
		// 숫자 카운트 (회사 소개 / 스펙)
		$$('[data-count]').forEach(function (el) {
			var end = parseFloat(el.dataset.count);
			if (isNaN(end)) return;
			var suffix = el.textContent.replace(/^[\d.,\s]+/, '');
			var o = { v: 0 };
			gsap.to(o, {
				v: end, duration: 1.6, ease: 'power3.out',
				scrollTrigger: { trigger: el, start: 'top 90%', once: true },
				onUpdate: function () { el.textContent = Math.round(o.v) + suffix; }
			});
		});

		// 서브 페이지 제목
		if ($('.page-head')) gsap.from('.page-head__title .ch', { yPercent: 100, opacity: 0, stagger: .025, duration: 1, ease: 'expo.out', delay: .2 });

		// 상세 페이지
		if ($('.pdp')) {
			gsap.from('.pdp__device > *', { y: 200, rotate: 25, opacity: 0, duration: 1.4, ease: 'elastic.out(1, .7)' });
			gsap.from('.pdp__name .ch', { yPercent: 100, opacity: 0, stagger: .03, duration: 1, ease: 'expo.out' });
			gsap.from('.pdp__copy > *', { y: 40, opacity: 0, stagger: .08, duration: 1, ease: 'expo.out', delay: .2 });
		}
	}

	/* ------------------------------------------------------ Film (intro) */
	function film() {
		var root = $('#top');
		if (!root) return;
		var video = $('video', root);
		var btn = $('.film__sound', root);
		if (video && btn) {
			btn.addEventListener('click', function () {
				video.muted = !video.muted;
				btn.setAttribute('aria-pressed', String(!video.muted));
				btn.textContent = video.muted ? 'Sound off' : 'Sound on';
			});
		}
		// 화면 밖에서는 영상 정지
		if (video) ST.create({ trigger: root, start: 'top bottom', end: 'bottom top', onToggle: function (s) { s.isActive ? video.play().catch(function () {}) : video.pause(); } });
	}
	function filmIntro() {
		if (!$('#top')) return;
		gsap.from('.film__bar > *', { y: 24, opacity: 0, duration: .9, stagger: .08, ease: 'expo.out' });
		gsap.from('.film__media--empty img', { y: 200, rotate: 20, opacity: 0, duration: 1.4, ease: 'elastic.out(1, .7)' });
	}

	/* ------------------------------------------- Flavour line-up + About */
	function about() {
		var row = $('#row');
		if (!row) return;
		var viewport = $('.row__viewport', row);
		var track = $('.row__track', row);
		var mains = $$('.row__item.is-main', row);
		var clones = $$('.row__item.is-clone', row);
		var n = mains.length;
		var st = { gap: 0, m: 0, speed: 0, run: false };
		var itemW = function () { return mains[0].offsetWidth || 60; };
		var tight = function () { return -itemW() * .45; };                   // 촘촘하게 붙어 서 있는 간격
		var loose = function () { return Math.min(90, Math.max(28, itemW() * .9)); }; // 펼쳐진 간격
		st.gap = tight();

		// 매 프레임: 간격 적용 + 가운데 정렬 + 왼쪽으로 흐르기(무한 반복)
		function layout() {
			var setW = n * (itemW() + st.gap);
			var base = (viewport.clientWidth - (setW - st.gap)) / 2 - setW;
			var m = ((st.m % setW) + setW) % setW;
			track.style.setProperty('--gap', st.gap + 'px');
			gsap.set(track, { x: base - m });
		}
		gsap.ticker.add(function (t, dt) {
			if (st.run) st.m += st.speed * dt / 1000;
			layout();
		});

		// 1) 영상에서 스크롤하면 일자로 선 채로 위에서 내려옴
		gsap.fromTo(track, { y: function () { return -window.innerHeight * .85; } }, {
			y: 0, ease: 'none',
			scrollTrigger: { trigger: row, start: 'top bottom', end: 'top top', scrub: true, invalidateOnRefresh: true }
		});

		// 3) 파스텔 원이 퐁퐁 꽃처럼 피어남
		var blooms = $$('.bloom', row);
		var bloomTl = gsap.timeline({ paused: true })
			.fromTo(blooms, { scale: 0, opacity: 0 }, { scale: 1, opacity: .95, duration: 1, ease: 'back.out(2.4)', stagger: { each: .09, from: 'random' } });

		// 2) 멈춘 상태에서 쫙 펼쳐지고 → 소개 글 등장 → 이후 계속 왼쪽으로 흐름
		var tl = gsap.timeline({
			scrollTrigger: {
				trigger: row, start: 'top top', end: '+=110%', pin: true, scrub: .5, invalidateOnRefresh: true,
				onUpdate: function (s) {
					// 파스텔 원: 펼쳐지기 시작하면 피어남
					if (s.progress > .12 && !st.bloomed) { st.bloomed = true; bloomTl.play(); }
					else if (s.progress < .05 && st.bloomed) { st.bloomed = false; bloomTl.reverse(); }
					var go = s.progress > .55;
					if (go !== st.run) {
						st.run = go;
						gsap.to(st, { speed: go ? 42 : 0, duration: 1.2, overwrite: 'auto' });
					}
				}
			}
		});
		tl.fromTo(st, { gap: function () { return tight(); } }, { gap: function () { return loose(); }, duration: 1, ease: 'power3.inOut', immediateRender: false }, 0)
			.fromTo(clones, { opacity: 0 }, { opacity: 1, duration: .3 }, .8)
			.fromTo('.about__intro > *', { y: 40, opacity: 0 }, { y: 0, opacity: 1, duration: .5, stagger: .08, ease: 'power2.out' }, .7);

		// 호버하면 멈춤 (맛 이름은 CSS 로 표시)
		viewport.addEventListener('pointerenter', function () { gsap.to(st, { speed: 0, duration: .5, overwrite: 'auto' }); });
		viewport.addEventListener('pointerleave', function () { if (st.run) gsap.to(st, { speed: 42, duration: .8, overwrite: 'auto' }); });

		blooms.forEach(function (b, i) {
			gsap.to(b, { xPercent: gsap.utils.random(-12, 12), yPercent: gsap.utils.random(-12, 12), duration: 4 + i % 4, ease: 'sine.inOut', yoyo: true, repeat: -1 });
		});

		// 펼쳐진 뒤 살짝 물결치듯
		$$('.row__item img', row).forEach(function (img, i) {
			gsap.to(img, { y: -8, duration: 1.8, ease: 'sine.inOut', yoyo: true, repeat: -1, delay: (i % n) * .12 });
		});
	}

	/* ------------------------------------------------------ Benefits/Steps */
	function blocks() {
		if ($('.benefits__list')) {
			gsap.from('.benefit', { y: 80, opacity: 0, rotate: function (i) { return i % 2 ? 3 : -3; }, stagger: .08, duration: 1, ease: 'expo.out', scrollTrigger: { trigger: '.benefits__list', start: 'top 85%' } });
		}
		$$('.steps').forEach(function (sec) {
			gsap.fromTo($('.steps__line i', sec), { scaleX: 0 }, { scaleX: 1, ease: 'none', scrollTrigger: { trigger: $('.steps__track', sec), start: 'top 75%', end: 'bottom 55%', scrub: true } });
			gsap.from($$('.step', sec), { y: 50, opacity: 0, stagger: .15, duration: .9, ease: 'expo.out', scrollTrigger: { trigger: $('.steps__track', sec), start: 'top 80%' } });
		});
		$$('.faq__item').forEach(function (d) {
			// 아코디언: 하나만 열기
			d.addEventListener('toggle', function () {
				if (d.open) $$('.faq__item').forEach(function (o) { if (o !== d) o.open = false; });
				ST.refresh();
			});
		});
	}

	/* ------------------------------------------------------------------ Run */
	var h = hero();
	if (!reduce) {
		film();
		about();
		lineup();
		flavors();
		device();
		blocks();
		cta();
		reveals();
	}
	if (reduce) {
		flavors();
	}
	ST.sort();

	ageGate()
		.then(loader)
		.then(function () {
			body.classList.remove('is-loading');
			h.intro();
			filmIntro();
			ST.refresh();
		});

	window.addEventListener('load', function () { ST.refresh(); });
})();

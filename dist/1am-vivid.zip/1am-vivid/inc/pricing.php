<?php
/**
 * 주(Province)별 가격 · 판매 지역 · GST
 *
 * 상품 편집 > General 탭 "Province prices" 에 한 줄씩:  BC: 80 / SK: 80 / AB: 90
 * - 가격은 배송지(=판매 지역, 소비세 스탬프 지역) 주에 따라 자동 적용
 *   (배송지 → 청구지 → 가입 때 입력한 매장 주 순서)
 * - 목록에 없는 주는 주문 불가, 결제 화면에서도 판매하는 주만 고를 수 있음
 * - 단위(Unit, 기본 carton) 와 "+ GST" 가 가격 옆에 표시
 * - 주문 상품마다 "Province / excise stamp" 기록
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** "BC: 80" 줄 → array( 'BC' => 80.0 ) */
function oneam_parse_province_prices( $text ) {
	$out = array();
	foreach ( preg_split( '/[\r\n,]+/', (string) $text ) as $line ) {
		if ( preg_match( '/^\s*([A-Za-z]{2})\s*[:=]\s*\$?\s*([\d.]+)/', $line, $m ) ) {
			$out[ strtoupper( $m[1] ) ] = (float) $m[2];
		}
	}
	return $out;
}

/** 상품(또는 옵션의 부모 상품)의 주별 가격 */
function oneam_province_prices( $product ) {
	if ( ! $product ) {
		return array();
	}
	$parent = $product->is_type( 'variation' ) ? wc_get_product( $product->get_parent_id() ) : $product;
	return $parent ? oneam_parse_province_prices( $parent->get_meta( '_oneam_prices' ) ) : array();
}

function oneam_unit_label( $product ) {
	$parent = $product && $product->is_type( 'variation' ) ? wc_get_product( $product->get_parent_id() ) : $product;
	$unit   = $parent ? trim( (string) $parent->get_meta( '_oneam_unit' ) ) : '';
	$unit = '' !== $unit ? $unit : 'carton';
	$pack = oneam_pack_count( $product );
	return $pack ? $unit . ' (' . $pack . ' pcs)' : $unit;
}

/** 한 단위(카톤)에 들어있는 개수 — 상품 편집 > Pieces per carton */
function oneam_pack_count( $product ) {
	$parent = $product && $product->is_type( 'variation' ) ? wc_get_product( $product->get_parent_id() ) : $product;
	return $parent ? (int) $parent->get_meta( '_oneam_pack' ) : 0;
}

/** 지금 손님의 주 (배송지 → 청구지 → 가입 때 매장 주) */
function oneam_customer_province() {
	$prov = '';
	if ( function_exists( 'WC' ) && WC()->customer ) {
		$prov = WC()->customer->get_shipping_state() ?: WC()->customer->get_billing_state();
	}
	if ( ! $prov && is_user_logged_in() ) {
		$prov = get_user_meta( get_current_user_id(), 'oneam_province', true );
	}
	return strtoupper( (string) $prov );
}

/** 이 상품의 지금 가격 (주별 가격이 없는 상품이면 null) */
function oneam_province_price( $product ) {
	$pp = oneam_province_prices( $product );
	if ( ! $pp ) {
		return null;
	}
	$prov = oneam_customer_province();
	if ( isset( $pp[ $prov ] ) ) {
		return $pp[ $prov ];
	}
	return min( $pp ); // 아직 주를 모를 때 (결제 화면에서 주를 고르면 다시 계산)
}

/* ---------------------------------------------------------------------------
 * 가격 적용
 * ------------------------------------------------------------------------- */
$oneam_price_filter = function ( $price, $product ) {
	$p = oneam_province_price( $product );
	return null === $p ? $price : $p;
};
foreach ( array( 'woocommerce_product_get_price', 'woocommerce_product_get_regular_price', 'woocommerce_product_variation_get_price', 'woocommerce_product_variation_get_regular_price' ) as $oneam_hook ) {
	add_filter( $oneam_hook, $oneam_price_filter, 20, 2 );
}
foreach ( array( 'woocommerce_variation_prices_price', 'woocommerce_variation_prices_regular_price' ) as $oneam_hook ) {
	add_filter(
		$oneam_hook,
		function ( $price, $variation ) {
			$p = oneam_province_price( $variation );
			return null === $p ? $price : $p;
		},
		20,
		2
	);
}
// 주마다 다른 가격이 캐시에 섞이지 않게
add_filter(
	'woocommerce_get_variation_prices_hash',
	function ( $hash ) {
		$hash[] = 'prov-' . oneam_customer_province();
		return $hash;
	}
);

/** 판매하지 않는 주(배송지가 정해진 경우)는 주문 불가 */
add_filter(
	'woocommerce_is_purchasable',
	function ( $ok, $product ) {
		$pp   = oneam_province_prices( $product );
		$prov = oneam_customer_province();
		if ( $ok && $pp && $prov && ! isset( $pp[ $prov ] ) ) {
			return false;
		}
		return $ok;
	},
	20,
	2
);
add_filter(
	'woocommerce_variation_is_purchasable',
	function ( $ok, $variation ) {
		$pp   = oneam_province_prices( $variation );
		$prov = oneam_customer_province();
		return ( $ok && $pp && $prov && ! isset( $pp[ $prov ] ) ) ? false : $ok;
	},
	20,
	2
);

/* ---------------------------------------------------------------------------
 * 입력한 가격이 GST 포함인지 · 별도인지 (관리자: 1AM Settings → Business & legal)
 * WooCommerce 설정(Prices entered with tax)과 같은 값 — 표시도 입력한 방식 그대로
 * ------------------------------------------------------------------------- */
function oneam_prices_incl_gst() {
	return 'yes' === get_option( 'woocommerce_prices_include_tax' );
}
/** 가격 옆 표시: "+ GST" 또는 "incl. GST" */
function oneam_gst_label() {
	return oneam_prices_incl_gst() ? 'incl. GST' : '+ GST';
}
/** 문장 속 표시: "before GST" 또는 "including GST" */
function oneam_gst_phrase() {
	return oneam_prices_incl_gst() ? 'including GST' : 'before GST';
}
/** 가격 입력 방식이 바뀌면 상점 · 장바구니 표시도 같은 방식으로 */
function oneam_sync_tax_display() {
	$mode = oneam_prices_incl_gst() ? 'incl' : 'excl';
	if ( get_option( 'woocommerce_tax_display_shop' ) !== $mode ) {
		update_option( 'woocommerce_tax_display_shop', $mode );
	}
	if ( get_option( 'woocommerce_tax_display_cart' ) !== $mode ) {
		update_option( 'woocommerce_tax_display_cart', $mode );
	}
}
add_action( 'update_option_woocommerce_prices_include_tax', 'oneam_sync_tax_display' );
// 화면 표시는 항상 입력한 방식 그대로 (WooCommerce 세금 설정에서 표시 방식을 따로 바꿔도
// "GST 별도 = $70 + GST" · "GST 포함 = $70 incl. GST" 로 숫자와 표기가 어긋나지 않게)
foreach ( array( 'woocommerce_tax_display_shop', 'woocommerce_tax_display_cart' ) as $oneam_opt_key ) {
	add_filter(
		'pre_option_' . $oneam_opt_key,
		function () {
			return oneam_prices_incl_gst() ? 'incl' : 'excl';
		}
	);
}
unset( $oneam_opt_key );
add_action( 'add_option_woocommerce_prices_include_tax', 'oneam_sync_tax_display' );
add_action( 'customize_save_after', 'oneam_sync_tax_display' );

/** 가격 옆에 "/ carton + GST" */
add_filter(
	'woocommerce_get_price_html',
	function ( $html, $product ) {
		if ( ! oneam_province_prices( $product ) || '' === $html ) {
			return $html;
		}
		return $html . ' <small class="oneam-unit">/ ' . esc_html( oneam_unit_label( $product ) ) . ' ' . esc_html( oneam_gst_label() ) . '</small>';
	},
	20,
	2
);

/** 결제 화면: 장바구니 상품을 판매하는 주만 선택 가능 */
add_filter(
	'woocommerce_states',
	function ( $states ) {
		if ( is_admin() || ! function_exists( 'WC' ) || ! WC()->cart || ! isset( $states['CA'] ) ) {
			return $states;
		}
		if ( ! ( function_exists( 'is_checkout' ) && ( is_checkout() || is_cart() ) ) && ! wp_doing_ajax() && ! ( defined( 'REST_REQUEST' ) && REST_REQUEST ) ) {
			return $states;
		}
		$allowed = oneam_sales_regions(); // 판매 주 (1AM Settings > Business & legal)
		foreach ( WC()->cart->get_cart() as $item ) {
			$pp = oneam_province_prices( $item['data'] );
			if ( $pp ) {
				$allowed = array_intersect( $allowed, array_keys( $pp ) );
			}
		}
		if ( $allowed ) {
			$states['CA'] = array_intersect_key( $states['CA'], array_flip( $allowed ) );
		}
		return $states;
	}
);

/** 주문 상품마다 판매 지역(소비세 스탬프) 기록 */
add_action(
	'woocommerce_checkout_create_order_line_item',
	function ( $item, $key, $values, $order ) {
		if ( oneam_province_prices( $values['data'] ) ) {
			$prov = $order->get_shipping_state() ?: $order->get_billing_state();
			$item->add_meta_data( 'Province / excise stamp', $prov, true );
			$item->add_meta_data( 'Excise stamp', oneam_stamp_label( $prov ), true );
		}
	},
	10,
	4
);

/* ---------------------------------------------------------------------------
 * 상품 편집 화면: Province prices · Unit
 * ------------------------------------------------------------------------- */
add_action(
	'woocommerce_product_options_general_product_data',
	function () {
		if ( function_exists( 'oneam_pe_active' ) && oneam_pe_active() ) {
			return; // "1AM product setup" 칸에서 입력
		}
		echo '<div class="options_group oneam-prices">';
		woocommerce_wp_textarea_input(
			array(
				'id'          => '_oneam_prices',
				'label'       => '1AM province prices',
				'placeholder' => "BC: 80\nSK: 80\nAB: 90",
				'description' => 'One province per line (code: price ' . oneam_gst_phrase() . '). Only these provinces can order, at these prices — this overrides the regular price. Leave empty to use the regular price everywhere.',
				'desc_tip'    => false,
				'rows'        => 4,
			)
		);
		woocommerce_wp_text_input(
			array(
				'id'          => '_oneam_unit',
				'label'       => 'Unit',
				'placeholder' => 'carton',
				'description' => 'Shown after the price, e.g. "$80.00 / carton ' . oneam_gst_label() . '".',
			)
		);
		woocommerce_wp_text_input(
			array(
				'id'          => '_oneam_pack',
				'label'       => 'Pieces per carton',
				'type'        => 'number',
				'placeholder' => 'e.g. 10',
				'description' => 'Shown with the price, on the product page and in the cart, e.g. "$80.00 / carton (10 pcs) ' . oneam_gst_label() . '".',
			)
		);
		woocommerce_wp_text_input(
			array(
				'id'          => '_oneam_nicotine',
				'label'       => 'Nicotine concentration',
				'placeholder' => 'e.g. 20 mg/mL',
				'description' => 'Shown in the product specs. Federal maximum: 20 mg/mL.',
			)
		);
		echo '</div>';
	},
	30
);
add_action(
	'woocommerce_admin_process_product_object',
	function ( $product ) {
		// phpcs:disable WordPress.Security.NonceVerification -- WooCommerce verifies the product save nonce.
		if ( isset( $_POST['_oneam_prices'] ) ) {
			$pp    = oneam_parse_province_prices( sanitize_textarea_field( wp_unslash( $_POST['_oneam_prices'] ) ) );
			$lines = array();
			foreach ( $pp as $code => $price ) {
				$lines[] = $code . ': ' . rtrim( rtrim( number_format( $price, 2, '.', '' ), '0' ), '.' );
			}
			$product->update_meta_data( '_oneam_prices', implode( "\n", $lines ) );
		}
		if ( isset( $_POST['_oneam_unit'] ) ) {
			$product->update_meta_data( '_oneam_unit', sanitize_text_field( wp_unslash( $_POST['_oneam_unit'] ) ) );
		}
		if ( isset( $_POST['_oneam_pack'] ) ) {
			$product->update_meta_data( '_oneam_pack', absint( wp_unslash( $_POST['_oneam_pack'] ) ) ?: '' );
		}
		if ( isset( $_POST['_oneam_nicotine'] ) ) {
			$product->update_meta_data( '_oneam_nicotine', sanitize_text_field( wp_unslash( $_POST['_oneam_nicotine'] ) ) );
		}
		// phpcs:enable
	}
);

/** 한 번만: Slim HYBRID 에 기본 판매 지역 · 가격 (BC/SK 80, AB 90 per carton) */
add_action(
	'admin_init',
	function () {
		if ( '1' === get_option( 'oneam_prices_v1' ) || ! function_exists( 'wc_get_product' ) ) {
			return;
		}
		$post = get_page_by_path( 'slim-hybrid', OBJECT, 'product' );
		if ( $post ) {
			$p = wc_get_product( $post->ID );
			if ( $p && ! $p->get_meta( '_oneam_prices' ) ) {
				$p->update_meta_data( '_oneam_prices', "BC: 80\nSK: 80\nAB: 90" );
				$p->update_meta_data( '_oneam_unit', 'carton' );
				$p->save();
			}
		}
		update_option( 'oneam_prices_v1', '1' );
	}
);

/** 한 번만: 우커머스 맛(옵션)에 남아 있는 예전 기본 설명 → 새 맛 특징 (장바구니 · 주문 메일에도 반영) */
add_action(
	'admin_init',
	function () {
		if ( '1' === get_option( 'oneam_flavour_desc_v1' ) || ! function_exists( 'wc_get_products' ) ) {
			return;
		}
		foreach ( wc_get_products( array( 'type' => 'variable', 'limit' => -1, 'status' => array( 'publish', 'draft', 'private' ) ) ) as $product ) {
			foreach ( $product->get_children() as $vid ) {
				$v = wc_get_product( $vid );
				if ( ! $v ) {
					continue;
				}
				$desc = trim( wp_strip_all_tags( $v->get_description() ) );
				if ( '' !== $desc && ! in_array( $desc, oneam_old_flavor_texts(), true ) ) {
					continue;
				}
				$attrs = $v->get_attributes();
				$def   = oneam_default_flavor_by_slug( sanitize_title( $attrs ? (string) reset( $attrs ) : '' ) );
				if ( $def ) {
					$v->set_description( $def[5] );
					$v->save();
				}
			}
		}
		update_option( 'oneam_flavour_desc_v1', '1' );
	}
);

/* ---------------------------------------------------------------------------
 * GST 5% 한 번에 설정 (WooCommerce 화면 안내)
 * ------------------------------------------------------------------------- */
function oneam_has_gst() {
	global $wpdb;
	return (bool) $wpdb->get_var( "SELECT tax_rate_id FROM {$wpdb->prefix}woocommerce_tax_rates WHERE tax_rate_country = 'CA' LIMIT 1" ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
}
add_action(
	'admin_post_oneam_setup_gst',
	function () {
		check_admin_referer( 'oneam_setup_gst' );
		if ( ! current_user_can( 'manage_woocommerce' ) || ! class_exists( 'WC_Tax' ) ) {
			wp_die( 'Not allowed.' );
		}
		oneam_setup_gst_rates();
		oneam_sync_tax_rates();
		wp_safe_redirect( admin_url( 'admin.php?page=wc-settings&tab=tax&section=standard' ) );
		exit;
	}
);

/* ---------------------------------------------------------------------------
 * 주별 세율 (GST / HST) — 기본값이 들어 있고 관리자가 상품 편집 화면에서 직접 고칠 수 있음
 * 저장하면 WooCommerce 세율 표(Tax → Standard rates)에 주별 줄로 들어감
 * ------------------------------------------------------------------------- */
function oneam_hst_provinces() {
	return array( 'ON', 'NB', 'NS', 'NL', 'PE' );
}
/** 기본 세율 (%) — GST 5%, HST 주는 HST */
function oneam_tax_defaults() {
	return array(
		'AB' => 5, 'BC' => 5, 'MB' => 5, 'SK' => 5, 'QC' => 5, 'YT' => 5, 'NT' => 5, 'NU' => 5,
		'ON' => 13, 'NB' => 15, 'NS' => 14, 'NL' => 15, 'PE' => 15,
	);
}
/** 지금 쓰는 주별 세율 (%) */
function oneam_tax_rates() {
	$saved = get_option( 'oneam_tax_rates' );
	$rates = array_map( 'floatval', oneam_tax_defaults() );
	if ( is_array( $saved ) ) {
		foreach ( $saved as $c => $r ) {
			if ( isset( $rates[ $c ] ) ) {
				$rates[ $c ] = (float) $r;
			}
		}
	}
	return $rates;
}
function oneam_tax_name( $code ) {
	return in_array( $code, oneam_hst_provinces(), true ) ? 'HST' : 'GST';
}
/** WooCommerce 세율 표에 주별 줄 넣기 (이 테마가 넣은 줄만 바꿈) */
function oneam_sync_tax_rates() {
	if ( ! class_exists( 'WC_Tax' ) ) {
		return;
	}
	foreach ( (array) get_option( 'oneam_tax_rate_ids', array() ) as $id ) {
		WC_Tax::_delete_tax_rate( (int) $id );
	}
	$ids = array();
	$i   = 0;
	foreach ( oneam_tax_rates() as $code => $rate ) {
		if ( $rate <= 0 ) {
			continue;
		}
		$ids[] = WC_Tax::_insert_tax_rate(
			array(
				'tax_rate_country'  => 'CA',
				'tax_rate_state'    => $code,
				'tax_rate'          => number_format( (float) $rate, 4, '.', '' ),
				'tax_rate_name'     => oneam_tax_name( $code ),
				'tax_rate_priority' => 1,
				'tax_rate_compound' => 0,
				'tax_rate_shipping' => 1,
				'tax_rate_order'    => $i++,
				'tax_rate_class'    => '',
			)
		);
	}
	update_option( 'oneam_tax_rate_ids', $ids, false );
}
// 처음 한 번: 세금이 켜져 있으면 기본 주별 세율을 넣어 둠 (BC · AB · SK · MB 는 지금과 같은 5%)
add_action(
	'admin_init',
	function () {
		if ( get_option( 'oneam_tax_rate_ids' ) || 'yes' !== get_option( 'woocommerce_calc_taxes' ) || ! current_user_can( 'manage_woocommerce' ) ) {
			return;
		}
		oneam_sync_tax_rates();
	}
);

/** 세금 켜기 + 캐나다 GST 5% (가격은 세전, 결제 화면에서 GST 별도 표시) */
function oneam_setup_gst_rates() {
	if ( ! class_exists( 'WC_Tax' ) ) {
		return false;
	}
	update_option( 'woocommerce_calc_taxes', 'yes' );
	if ( false === get_option( 'woocommerce_prices_include_tax', false ) ) {
		update_option( 'woocommerce_prices_include_tax', 'no' );
	}
	oneam_sync_tax_display();
	update_option( 'woocommerce_tax_based_on', 'shipping' );
	if ( ! oneam_has_gst() ) {
		WC_Tax::_insert_tax_rate(
			array(
				'tax_rate_country'  => 'CA',
				'tax_rate_state'    => '',
				'tax_rate'          => '5.0000',
				'tax_rate_name'     => 'GST',
				'tax_rate_priority' => 1,
				'tax_rate_compound' => 0,
				'tax_rate_shipping' => 1,
				'tax_rate_order'    => 0,
				'tax_rate_class'    => '',
			)
		);
	}
	return true;
}
add_action(
	'admin_notices',
	function () {
		$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
		if ( ! $screen || ! current_user_can( 'manage_woocommerce' ) || ! class_exists( 'WC_Tax' ) ) {
			return;
		}
		if ( ! in_array( $screen->id, array( 'woocommerce_page_wc-settings', 'edit-product', 'product' ), true ) ) {
			return;
		}
		if ( 'yes' === get_option( 'woocommerce_calc_taxes' ) && oneam_has_gst() ) {
			return;
		}
		printf(
			'<div class="notice notice-info"><p><strong>1AM:</strong> Turn on taxes and add 5%% GST for Canada (tax based on the shipping address). <a class="button button-primary" href="%s">Set up 5%% GST</a></p></div>',
			esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=oneam_setup_gst' ), 'oneam_setup_gst' ) )
		);
	}
);

/** 판매 지역 (승인 회원이면 주별 가격까지) — 상품 정보에 표시 */
function oneam_regions_html( $regions, $product = null ) {
	$regions = array_filter( (array) $regions );
	if ( ! $regions ) {
		return '';
	}
	$pp   = $product ? oneam_province_prices( $product ) : array();
	$show = $pp && 'approved' === oneam_member_state();
	$you  = oneam_customer_province();
	if ( $show && function_exists( 'oneam_tier_price' ) ) {
		foreach ( $pp as $c => $v ) {
			$t        = oneam_tier_price( $product, $v, $c ); // 그 주의 등급 가격 (VIP 등)
			$pp[ $c ] = null === $t ? $v : $t;
		}
	}
	$pick = $show && is_product(); // 상품 페이지: 눌러서 주(배송지) 선택
	$out  = '<ul class="pinfo__regions' . ( $pick ? ' is-pick' : '' ) . '" aria-label="Available in"' . ( $pick ? ' data-nonce="' . esc_attr( wp_create_nonce( 'oneam_prov' ) ) . '"' : '' ) . '>';
	foreach ( $regions as $code ) {
		$label = $code;
		if ( $show && isset( $pp[ $code ] ) ) {
			$label .= ' ' . wp_strip_all_tags( wc_price( $pp[ $code ] ) ) . ' / ' . oneam_unit_label( $product ) . ' ' . oneam_gst_label();
		}
		if ( $pick && isset( $pp[ $code ] ) && ! oneam_account_can_ship_to( $code ) ) {
			$out .= '<li class="is-off" title="' . esc_attr( 'Your account is not registered for a store in ' . ( oneam_provinces()[ $code ] ?? $code ) . '. Contact us to add one.' ) . '">' . esc_html( $label ) . '</li>';
		} elseif ( $pick && isset( $pp[ $code ] ) ) {
			$out .= '<li' . ( $code === $you ? ' class="is-you"' : '' ) . '><button type="button" data-prov="' . esc_attr( $code ) . '" data-name="' . esc_attr( oneam_provinces()[ $code ] ?? $code ) . '" data-price="' . esc_attr( wc_price( $pp[ $code ] ) ) . '" aria-pressed="' . ( $code === $you ? 'true' : 'false' ) . '">' . esc_html( $label ) . '</button></li>';
		} elseif ( $product && ( ! $pp || isset( $pp[ $code ] ) ) ) {
			// 소개 페이지 등: 누르면 그 주가 선택된 상품 페이지로
			$out .= '<li' . ( $code === $you ? ' class="is-you"' : '' ) . '><a href="' . esc_url( add_query_arg( 'oneam_prov', $code, get_permalink( $product->get_id() ) ) ) . '">' . esc_html( $label ) . '</a></li>';
		} else {
			$out .= '<li' . ( $code === $you ? ' class="is-you"' : '' ) . '>' . esc_html( $label ) . '</li>';
		}
	}
	return $out . '</ul>';
}

/** 상품 페이지에서 주를 누르면: 손님의 배송 주를 바꿔 가격 · 스탬프 · 결제 화면 주소에 반영 */
function oneam_ajax_set_province() {
	check_ajax_referer( 'oneam_prov', 'nonce' );
	$prov = strtoupper( sanitize_text_field( wp_unslash( $_POST['prov'] ?? '' ) ) );
	if ( ! in_array( $prov, oneam_sales_regions(), true ) || ! oneam_account_can_ship_to( $prov ) || ! function_exists( 'WC' ) || ! WC()->customer ) {
		wp_send_json_error();
	}
	WC()->customer->set_shipping_country( 'CA' );
	WC()->customer->set_shipping_state( $prov );
	if ( ! WC()->customer->get_billing_state() ) {
		WC()->customer->set_billing_country( 'CA' );
		WC()->customer->set_billing_state( $prov );
	}
	WC()->customer->save();
	if ( WC()->cart ) {
		WC()->cart->calculate_totals();
	}
	wp_send_json_success( array( 'prov' => $prov ) );
}
add_action( 'wp_ajax_oneam_set_province', 'oneam_ajax_set_province' );
add_action( 'wp_ajax_nopriv_oneam_set_province', 'oneam_ajax_set_province' );

/* ---------------------------------------------------------------------------
 * 결제 수단 표시 (카드사 · Moneris 요구: 사용 가능한 카드 · 통화 · 보안 결제 안내)
 * ------------------------------------------------------------------------- */
function oneam_payment_badges() {
	$methods = array_filter( array_map( 'trim', explode( '·', (string) oneam_opt( 'oneam_payments' ) ) ) );
	$out     = '<div class="paybadges"><p class="paybadges__title">' . oneam_icon( 'check' ) . ' ' . ( oneam_opt( 'oneam_processor' ) ? 'Secure payment by ' . esc_html( oneam_opt( 'oneam_processor' ) ) : 'Payment' ) . ' · CAD</p><ul>';
	foreach ( $methods as $m ) {
		$out .= '<li>' . esc_html( $m ) . '</li>';
	}
	return $out . '</ul></div>';
}
// 블록 결제 · 장바구니 화면
add_filter(
	'render_block',
	function ( $html, $block ) {
		// 결제 블록 안쪽은 우커머스 스크립트가 다시 그리므로, 결제 · 장바구니 화면 전체 아래에 표시
		// 카드 결제사(Moneris 등)를 설정했을 때만 표시 — e-Transfer만 쓸 때는 결제 방법 칸에 이미 안내가 있음
		return oneam_opt( 'oneam_processor' ) && in_array( $block['blockName'] ?? '', array( 'woocommerce/checkout', 'woocommerce/cart' ), true ) ? $html . oneam_payment_badges() : $html;
	},
	10,
	2
);
// 클래식 결제 화면
add_action( 'woocommerce_review_order_after_payment', function () { echo oneam_payment_badges(); } ); // phpcs:ignore

/* ---------------------------------------------------------------------------
 * Interac e-Transfer 결제 (지금은 e-Transfer 만, 카드는 Moneris 연결 후)
 * 우커머스 기본 "Direct bank transfer" 를 e-Transfer 로 설정 (블록 결제 화면 지원)
 * 받는 이메일: 사용자 정의하기 > 1AM Settings > Checkout confirmation > Interac e-Transfer email
 * ------------------------------------------------------------------------- */
function oneam_etransfer_email() {
	return oneam_opt( 'oneam_etransfer' ) ?: oneam_opt( 'oneam_email' );
}

function oneam_setup_etransfer() {
	if ( ! class_exists( 'WooCommerce' ) ) {
		return;
	}
	$email = oneam_etransfer_email();
	$bacs  = (array) get_option( 'woocommerce_bacs_settings', array() );
	update_option(
		'woocommerce_bacs_settings',
		array_merge(
			$bacs,
			array(
				'enabled'      => 'yes',
				'title'        => 'Interac e-Transfer',
				'description'  => "After you place your order, send an Interac e-Transfer for the order total to {$email}. Put your order number in the message. Your order ships once payment is received.",
				'instructions' => "Please send an Interac e-Transfer for the order total to {$email} and include your order number in the message. We process your order as soon as the payment arrives. " . oneam_unpaid_note() . "",
			)
		)
	);
	update_option( 'woocommerce_bacs_accounts', array() ); // 은행 계좌 표는 표시하지 않음
	// 지금은 e-Transfer 만: 수표 · 착불 결제 끄기
	foreach ( array( 'cheque', 'cod' ) as $gw ) {
		$o = (array) get_option( "woocommerce_{$gw}_settings", array() );
		if ( ( $o['enabled'] ?? 'no' ) === 'yes' ) {
			$o['enabled'] = 'no';
			update_option( "woocommerce_{$gw}_settings", $o );
		}
	}
}
// 테마 업데이트 후 한 번, 그리고 사용자 정의하기에서 이메일을 바꾸면 다시 적용
add_action(
	'admin_init',
	function () {
		if ( ONEAM_VERSION !== get_option( 'oneam_etransfer_v' ) ) {
			oneam_setup_etransfer();
			if ( function_exists( 'oneam_setup_checkout_terms' ) ) {
				oneam_setup_checkout_terms();
			}
			update_option( 'oneam_etransfer_v', ONEAM_VERSION );
		}
	}
);
add_action( 'customize_save_after', 'oneam_setup_etransfer' );

/** 주문 완료 화면 · 주문 메일: 보낼 금액 · 이메일 · 주문번호를 정확히 */
function oneam_etransfer_box( $order, $plain = false ) {
	if ( ! $order || 'bacs' !== $order->get_payment_method() || $order->is_paid() ) {
		return;
	}
	$total = wp_strip_all_tags( wc_price( $order->get_total(), array( 'currency' => $order->get_currency() ) ) );
	$email = oneam_etransfer_email();
	$num   = $order->get_order_number();
	if ( $plain ) {
		echo "\nINTERAC E-TRANSFER\nSend: {$total}\nTo: {$email}\nMessage: Order #{$num}\n" . oneam_unpaid_note() . "\n\n"; // phpcs:ignore
		return;
	}
	printf(
		'<div class="etransfer"><p class="etransfer__title">Pay by Interac e-Transfer</p><dl><div><dt>Send</dt><dd>%s</dd></div><div><dt>To</dt><dd>%s</dd></div><div><dt>Message</dt><dd>Order #%s</dd></div></dl><p class="etransfer__note">We process your order as soon as the payment arrives. ' . esc_html( oneam_unpaid_note() ) . '</p></div>',
		esc_html( $total ),
		esc_html( $email ),
		esc_html( $num )
	);
}
add_action(
	'woocommerce_thankyou_bacs',
	function ( $order_id ) {
		$order = wc_get_order( $order_id );
		oneam_etransfer_box( $order );
		// 카드에 같은 안내가 있으니 아래에 한 번 더 나오는 기본 안내문은 빼기
		if ( $order && ! $order->is_paid() ) {
			$gw = WC()->payment_gateways() ? ( WC()->payment_gateways()->payment_gateways()['bacs'] ?? null ) : null;
			if ( $gw ) {
				remove_action( 'woocommerce_thankyou_bacs', array( $gw, 'thankyou_page' ) );
			}
		}
	},
	5
);
/** 주문 완료 화면: 다음 행동 버튼 (내 주문 보기 · 쇼핑 계속하기) */
add_action(
	'woocommerce_thankyou',
	function ( $order_id ) {
		$order = wc_get_order( $order_id );
		if ( ! $order ) {
			return;
		}
		$orders = is_user_logged_in() ? wc_get_account_endpoint_url( 'orders' ) : '';
		?>
		<div class="thanks-next">
			<div class="thanks-next__text">
				<strong>What happens next</strong>
				<span>We confirm your payment, pack your cartons and email tracking when it ships. You can follow the status in My account &rarr; Orders.</span>
			</div>
			<div class="thanks-next__btns">
				<?php if ( $orders ) : ?>
					<a class="btn btn--solid" href="<?php echo esc_url( $orders ); ?>"><span>View my orders &rarr;</span></a>
				<?php endif; ?>
				<a class="btn btn--ghost" href="<?php echo esc_url( oneam_shop_url() ); ?>"><span>Continue shopping</span></a>
			</div>
		</div>
		<?php
	},
	5
);
add_action(
	'woocommerce_email_before_order_table',
	function ( $order, $sent_to_admin, $plain ) {
		if ( ! $sent_to_admin ) {
			oneam_etransfer_box( $order, $plain );
		}
	},
	5,
	3
);

/* -------------------------------------------------------------------------
 * 결제 화면 문구 · 주문 메모
 *  - "Additional order information" → "Required confirmations" (소비세 스탬프 확인은 필수 항목)
 *  - 주문 메모: 청구지 주소 아래, 체크 없이 바로 적는 칸
 * ------------------------------------------------------------------------- */
add_action(
	'wp_enqueue_scripts',
	function () {
		if ( ! function_exists( 'is_checkout' ) || ! is_checkout() ) {
			return;
		}
		$map = array(
			'Additional order information' => 'Required confirmations',
			'Add a note to your order'     => 'Order notes (optional)',
			'Notes about your order, e.g. special notes for delivery.' => 'Anything we should know? e.g. delivery instructions, store hours.',
		);
		wp_add_inline_script(
			'wp-i18n',
			'(function(m){if(window.wp&&wp.hooks){wp.hooks.addFilter("i18n.gettext_woocommerce","oneam/checkout",function(t,x){return m[x]||t;});}})(' . wp_json_encode( $map ) . ');'
			. 'document.addEventListener("DOMContentLoaded",function(){var n=0,t=setInterval(function(){var b=document.querySelector(".wc-block-checkout__add-note input[type=checkbox]");if(b){if(!b.checked){b.click();}clearInterval(t);}if(++n>60){clearInterval(t);}},250);});'
		);
	},
	20
);

// 내 계정: "Downloads"(디지털 파일 상품용) 탭은 이 사이트에서 쓰지 않으므로 숨김
add_filter(
	'woocommerce_account_menu_items',
	function ( $items ) {
		unset( $items['downloads'] );
		return $items;
	}
);

// 장바구니 · 결제 · 주문서: "Carton: 10 pcs"
add_filter(
	'woocommerce_get_item_data',
	function ( $data, $item ) {
		$pack = isset( $item['data'] ) ? oneam_pack_count( $item['data'] ) : 0;
		if ( $pack ) {
			$unit   = trim( (string) ( $item['data']->is_type( 'variation' ) ? wc_get_product( $item['data']->get_parent_id() )->get_meta( '_oneam_unit' ) : $item['data']->get_meta( '_oneam_unit' ) ) ) ?: 'carton';
			$data[] = array( 'key' => ucfirst( $unit ), 'value' => $pack . ' pcs' );
		}
		return $data;
	},
	10,
	2
);
add_action(
	'woocommerce_checkout_create_order_line_item',
	function ( $item, $key, $values ) {
		$pack = isset( $values['data'] ) ? oneam_pack_count( $values['data'] ) : 0;
		if ( $pack ) {
			$item->add_meta_data( 'Pieces per carton', $pack, true );
		}
	},
	10,
	3
);

// 상품 주소에 ?oneam_prov=AB 가 있으면 그 주로 선택 (소개 페이지의 주 버튼)
add_action(
	'template_redirect',
	function () {
		if ( empty( $_GET['oneam_prov'] ) || ! function_exists( 'WC' ) || ! WC()->customer || ! is_user_logged_in() ) { // phpcs:ignore WordPress.Security.NonceVerification
			return;
		}
		$prov = strtoupper( sanitize_text_field( wp_unslash( $_GET['oneam_prov'] ) ) ); // phpcs:ignore WordPress.Security.NonceVerification
		if ( oneam_account_can_ship_to( $prov ) ) {
			WC()->customer->set_shipping_country( 'CA' );
			WC()->customer->set_shipping_state( $prov );
			WC()->customer->save();
		}
	},
	5
);

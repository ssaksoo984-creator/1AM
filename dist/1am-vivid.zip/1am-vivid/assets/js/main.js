/* ==========================================================================
   1AM Vivid — main.js
   GSAP + ScrollTrigger + Lenis
   ========================================================================== */
(function () {
	'use strict';

	var cfg = window.ONEAM || { ageGate: true };
	var gsap = window.gsap;
	var ST = window.ScrollTrigger;
	var $ = function (s, c) { return (c || document).querySelector(s); };
	var $$ = function (s, c) { return Array.prototype.slice.call((c || document).querySelectorAll(s)); };
	var body = document.body;
	var reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
	var lite = !!cfg.lite; // 쇼핑몰(장바구니·결제·내 계정) 페이지
	// Elementor 편집 화면: 스크롤 애니메이션 없이 완성된 모습만 (CSS .is-builder)
	var builder = !!cfg.builder || body.classList.contains('elementor-editor-active');
	if (builder) {
		body.classList.add('is-builder');
		body.classList.remove('is-loading');
		return;
	}
	var finePointer = window.matchMedia('(hover: hover) and (pointer: fine)').matches;

	if (!gsap) { body.classList.remove('is-loading'); return; }
	gsap.registerPlugin(ST);

	// 나이 확인은 방문할 때마다(브라우저 탭을 새로 열 때마다) — 같은 방문 안에서 페이지를 옮길 때는 다시 묻지 않음
	var store = {
		get: function (k) { try { return window.sessionStorage.getItem(k); } catch (e) { return null; } },
		set: function (k, v) { try { window.sessionStorage.setItem(k, v); } catch (e) { /* noop */ } }
	};

	/* ---------------------------------------------------------------- Lenis */
	var lenis = null;
	if (window.Lenis && !reduce && !lite) {
		lenis = new window.Lenis({ lerp: 0.1, smoothWheel: true });
		lenis.on('scroll', ST.update);
		window.ONEAM_LENIS = lenis; // 팝업이 열려 있는 동안 멈춤
		gsap.ticker.add(function (t) { lenis.raf(t * 1000); });
		gsap.ticker.lagSmoothing(0);
	}
	function lock(on) {
		body.classList.toggle('is-locked', on);
		if (lenis) { on ? lenis.stop() : lenis.start(); }
	}

	// 앵커 링크 부드럽게
	$$('a[href*="#"]').forEach(function (a) {
		a.addEventListener('click', function (e) {
			var url = new URL(a.href, location.href);
			if (url.pathname !== location.pathname || !url.hash) return;
			var target = $(url.hash);
			if (!target) return;
			e.preventDefault();
			closeMenu();
			if (lenis) lenis.scrollTo(target, { offset: 0, duration: 1.4 });
			else target.scrollIntoView({ behavior: reduce ? 'auto' : 'smooth' });
		});
	});

	/* ------------------------------------------------------------- Age gate */
	function ageGate() {
		return new Promise(function (resolve) {
			var gate = $('#agegate');
			if (!gate || !cfg.ageGate || store.get('oneam_age') === '1') { resolve(); return; }
			gate.hidden = false;
			lock(true);
			gsap.from('.agegate__box', { y: 60, opacity: 0, duration: 1, ease: 'expo.out' });
			gate.addEventListener('click', function (e) {
				var btn = e.target.closest('[data-age]');
				if (!btn) return;
				if (btn.dataset.age === 'no') {
					gate.classList.add('is-denied');
					$('.agegate__txt', gate).textContent = 'Sorry, this site is for adults only.';
					gsap.fromTo('.agegate__box', { x: -10 }, { x: 0, duration: .5, ease: 'elastic.out(1, .3)' });
					return;
				}
				store.set('oneam_age', '1');
				gsap.to(gate, {
					clipPath: 'inset(0 0 100% 0)', duration: .9, ease: 'expo.inOut',
					onComplete: function () { gate.remove(); lock(false); resolve(); }
				});
			});
		});
	}

	/* --------------------------------------------------------------- Loader */
	function loader() {
		return new Promise(function (resolve) {
			var el = $('#loader');
			if (!el || reduce) { resolve(); return; }
			try { sessionStorage.setItem('oneam_loaded', '1'); } catch (e) {}
			var num = $('#loader-num');
			var o = { m: 0 };
			var tl = gsap.timeline({ onComplete: resolve });
			tl.from('.loader__logo', { scale: .6, opacity: 0, duration: .8, ease: 'expo.out' })
				.to(o, {
					m: 60, duration: 1.1, ease: 'power2.inOut',
					onUpdate: function () {
						var m = Math.round(o.m);
						num.textContent = (m === 60 ? '01:00' : '00:' + String(m).padStart(2, '0')) + ' AM';
					}
				}, '<.1')
				.to('.loader__inner', { y: -40, opacity: 0, duration: .5, ease: 'power3.in' }, '+=.15')
				.to('.loader__bg', { clipPath: 'circle(0% at 50% 50%)', duration: 1, ease: 'expo.inOut' }, '-=.2');
		});
	}

	/* --------------------------------------------------------------- Header */
	var header = $('#site-header');
	var lastY = 0;
	function onScrollHeader(y) {
		if (!header || body.classList.contains('nav-open')) return;
		header.classList.toggle('is-scrolled', y > 10);
		// 아래로 내릴 때는 헤더 숨김, 위로 올릴 때는 다시 보임 (맨 위 근처에서는 항상 보임)
		if (Math.abs(y - lastY) > 4) header.classList.toggle('is-hidden', y > lastY && y > 160);
		lastY = y;
		headerTone();
	}

	// 헤더 뒤에 있는 섹션이 어두우면 흰 글씨(is-dark), 밝으면 검은 글씨
	// 섹션에 data-header="light"(=흰 글씨) / "dark"(=검은 글씨)가 있으면 그대로, 없으면 배경색 밝기로 판단
	var toneRaf = 0;
	function bgTone(el) {
		for (; el && el !== document.documentElement; el = el.parentElement) {
			if (el.dataset && el.dataset.header) return el.dataset.header === 'light' ? 'dark' : 'light';
			var cs = getComputedStyle(el);
			var m = cs.backgroundColor.match(/[\d.]+/g);
			if (m && (m.length < 4 || +m[3] > .5)) {
				var lum = (0.2126 * m[0] + 0.7152 * m[1] + 0.0722 * m[2]) / 255;
				return lum < .5 ? 'dark' : 'light';
			}
			if (cs.backgroundImage && cs.backgroundImage !== 'none') return 'dark'; // 사진 · 그라데이션 배경
			if (el.tagName === 'VIDEO' || el.tagName === 'CANVAS') return 'dark';
		}
		return 'light';
	}
	function headerTone() {
		if (!header || toneRaf) return;
		// 홈만 배경에 맞춰 글자색이 바뀜 · 다른 페이지는 항상 흰 바탕에 검은 글씨
		if (!document.body.classList.contains('home')) { header.classList.remove('is-dark'); return; }
		toneRaf = requestAnimationFrame(function () {
			toneRaf = 0;
			var r = header.getBoundingClientRect();
			var y = r.bottom - 4, dark = 0;
			// 왼쪽 · 가운데 · 오른쪽 세 군데를 보고 더 많은 쪽으로
			[.06, .5, .94].forEach(function (fx) {
				var list = document.elementsFromPoint ? document.elementsFromPoint(window.innerWidth * fx, y) : [];
				for (var i = 0; i < list.length; i++) {
					if (list[i].closest('#site-header, .topbar, .cursor, .loader, #wpadminbar')) continue;
					if (bgTone(list[i]) === 'dark') dark++;
					break;
				}
			});
			header.classList.toggle('is-dark', dark >= 2);
		});
	}
	window.addEventListener('scroll', headerTone, { passive: true });
	window.addEventListener('resize', headerTone);
	window.addEventListener('load', headerTone);
	headerTone();
	if (lenis) lenis.on('scroll', function (l) { onScrollHeader(l.scroll); });
	else window.addEventListener('scroll', function () { onScrollHeader(window.scrollY); }, { passive: true });

	/* ----------------------------------------------------------------- Menu */
	var menuBtn = $('#menu-btn');
	function closeMenu() {
		if (!body.classList.contains('nav-open')) return;
		body.classList.remove('nav-open');
		menuBtn && menuBtn.setAttribute('aria-expanded', 'false');
	}
	if (menuBtn) {
		menuBtn.addEventListener('click', function () {
			if (body.classList.contains('nav-open')) { closeMenu(); return; }
			body.classList.add('nav-open');
			menuBtn.setAttribute('aria-expanded', 'true');
		});
		document.addEventListener('keydown', function (e) { if (e.key === 'Escape') closeMenu(); });
	}

	/* --------------------------------------------------------------- Cursor */
	if (finePointer && !reduce && !lite) {
		var cursor = $('.cursor');
		var label = $('.cursor__label');
		var xTo = gsap.quickTo(cursor, 'x', { duration: .35, ease: 'power3' });
		var yTo = gsap.quickTo(cursor, 'y', { duration: .35, ease: 'power3' });
		window.addEventListener('pointermove', function (e) { xTo(e.clientX); yTo(e.clientY); });
		document.addEventListener('pointerover', function (e) {
			var t = e.target.closest('[data-cursor], a, button');
			cursor.classList.toggle('is-hover', !!t);
			var lbl = t && t.closest('[data-cursor]');
			cursor.classList.toggle('has-label', !!lbl);
			label.textContent = lbl ? lbl.dataset.cursor : '';
		});

		// 마그네틱 버튼
		$$('[data-magnetic]').forEach(function (el) {
			var mx = gsap.quickTo(el, 'x', { duration: .6, ease: 'elastic.out(1, .4)' });
			var my = gsap.quickTo(el, 'y', { duration: .6, ease: 'elastic.out(1, .4)' });
			el.addEventListener('pointermove', function (e) {
				var r = el.getBoundingClientRect();
				mx((e.clientX - r.left - r.width / 2) * .35);
				my((e.clientY - r.top - r.height / 2) * .35);
			});
			el.addEventListener('pointerleave', function () { mx(0); my(0); });
		});
	}

	/* ----------------------------------------------------------------- Hero */
	function setBodyColors(c1, c2, dur) {
		gsap.to(body, { '--c1': c1, '--c2': c2, duration: dur == null ? 1 : dur, ease: 'power2.out', overwrite: 'auto' });
	}

	function hero() {
		var root = $('#hero');
		if (!root) return { intro: function () {} };
		var devices = $$('.hero__device', root);
		var names = $$('.hero__name', root);
		var dots = $$('.hero__dots button', root);
		var idxEl = $('#hero-idx');
		var nameEl = $('#hero-flavor');
		var descEl = $('#hero-desc');
		var bar = $('.hero__progress span', root);
		var cur = 0;
		var busy = false;
		var DURATION = 5;
		var autoplay;

		// 첫 번째 외의 디바이스는 GSAP 가 제어
		devices.forEach(function (d, i) { if (i) gsap.set(d, { opacity: 0 }); });
		gsap.set(devices[0], { opacity: 1, rotate: -6, y: 0, scale: 1 });

		function go(next, dir) {
			if (busy || next === cur) return;
			busy = true;
			dir = dir || (next > cur ? 1 : -1);
			var from = devices[cur];
			var to = devices[next];
			var d = to.dataset;

			setBodyColors(d.c1, d.c2, 1);

			gsap.to(from, { y: -120 * dir, rotate: -6 + 30 * dir, opacity: 0, scale: .85, duration: .7, ease: 'power3.in' });
			gsap.fromTo(to,
				{ y: 160 * dir, rotate: -6 - 40 * dir, opacity: 0, scale: .8 },
				{ y: 0, rotate: -6, opacity: 1, scale: 1, duration: 1.2, delay: .35, ease: 'elastic.out(1, .6)', onComplete: function () { busy = false; } });

			names[cur].classList.remove('is-active');
			names[cur].classList.add('is-leaving');
			(function (n) { setTimeout(function () { n.classList.remove('is-leaving'); }, 900); })(names[cur]);
			names[next].classList.add('is-active');

			dots.forEach(function (b, i) { b.classList.toggle('is-active', i === next); });

			gsap.to([nameEl, descEl], {
				y: -14, opacity: 0, duration: .25, ease: 'power2.in', onComplete: function () {
					nameEl.textContent = d.name;
					descEl.textContent = d.desc;
					idxEl.textContent = String(next + 1).padStart(2, '0');
					gsap.fromTo([nameEl, descEl], { y: 14, opacity: 0 }, { y: 0, opacity: 1, duration: .5, stagger: .06, ease: 'power3.out' });
				}
			});

			cur = next;
			restart();
		}
		function nextSlide() { go((cur + 1) % devices.length, 1); }
		function prevSlide() { go((cur - 1 + devices.length) % devices.length, -1); }

		function restart() {
			if (autoplay) autoplay.kill();
			autoplay = gsap.fromTo(bar, { scaleX: 0 }, { scaleX: 1, duration: DURATION, ease: 'none', onComplete: nextSlide });
		}

		$$('[data-hero]', root).forEach(function (b) {
			b.addEventListener('click', function () { b.dataset.hero === 'next' ? nextSlide() : prevSlide(); });
		});
		dots.forEach(function (b) { b.addEventListener('click', function () { go(+b.dataset.idx); }); });
		root.addEventListener('keydown', function (e) {
			if (e.key === 'ArrowRight') nextSlide();
			if (e.key === 'ArrowLeft') prevSlide();
		});

		// 스와이프 / 드래그
		var sx = null;
		root.addEventListener('pointerdown', function (e) { if (!e.target.closest('button, a')) sx = e.clientX; });
		window.addEventListener('pointerup', function (e) {
			if (sx === null) return;
			var dx = e.clientX - sx;
			sx = null;
			if (Math.abs(dx) > 50) (dx < 0 ? nextSlide : prevSlide)();
		});

		// 마우스 패럴랙스
		if (finePointer && !reduce) {
			var stage = $('.hero__stage', root);
			var rx = gsap.quickTo(stage, 'rotationY', { duration: .8, ease: 'power3' });
			var ry = gsap.quickTo(stage, 'rotationX', { duration: .8, ease: 'power3' });
			var sxTo = gsap.quickTo(stage, 'x', { duration: 1, ease: 'power3' });
			var orbs = $$('.orb', root);
			root.addEventListener('pointermove', function (e) {
				var px = e.clientX / window.innerWidth - .5;
				var py = e.clientY / window.innerHeight - .5;
				rx(px * 30); ry(-py * 20); sxTo(px * 40);
				orbs.forEach(function (o, i) { gsap.to(o, { x: px * (40 + i * 30), y: py * (40 + i * 30), duration: 1.2, ease: 'power3', overwrite: 'auto' }); });
			});
		}

		// 스크롤 시 히어로 빠져나가기
		gsap.timeline({ scrollTrigger: { trigger: root, start: 'top top', end: 'bottom top', scrub: true } })
			.to('.hero__names', { yPercent: 30, scale: 1.2 }, 0)
			.to('.hero__stage', { y: -120, scale: .9 }, 0)
			.to('.hero__copy, .hero__ctrl', { y: -80, opacity: 0 }, 0);

		// 화면 밖이면 자동재생 일시정지
		ST.create({ trigger: root, start: 'top bottom', end: 'bottom top', onToggle: function (s) { autoplay && (s.isActive ? autoplay.resume() : autoplay.pause()); } });

		return {
			intro: function () {
				var tl = gsap.timeline({ onComplete: restart });
				tl.from('.hero__title .line > span', { yPercent: 110, duration: 1.1, stagger: .1, ease: 'expo.out' })
					.from('.hero__kicker', { y: 20, opacity: 0, duration: .8, ease: 'expo.out' }, 0.1)
					.from(devices[0], { y: 300, rotate: 30, opacity: 0, duration: 1.6, ease: 'elastic.out(1, .7)' }, 0)
					.from('.hero__ctrl > *, .hero__dots, .hero__scroll', { y: 30, opacity: 0, duration: .8, stagger: .06, ease: 'expo.out' }, .3)
					.from('.orb', { scale: 0, duration: 1.2, stagger: .1, ease: 'back.out(2)' }, .2);
			}
		};
	}

	/* ------------------------------------------------- Product line-up */
	// 카드가 세로로 쌓이는 구조 (CSS sticky) — 스크롤은 그대로, 들어올 때 한 번만 등장
	function lineup() {
		var cards = $$('.pitem');
		if (!cards.length) return;
		cards.forEach(function (card) {
			var img = $('.pitem__img, .ghost', card);
			if (img) gsap.from(img, { y: 160, rotate: card.classList.contains('is-flip') ? 30 : -30, scale: .8, opacity: 0, duration: 1.4, ease: 'elastic.out(1, .7)', scrollTrigger: { trigger: card, start: 'top 80%', once: true } });
			// 계속 둥둥 떠 있는 움직임 (제품 · 배경 원)
			var vis = $('.pitem__visual', card);
			if (vis) gsap.to(vis, { y: -18, rotate: card.classList.contains('is-flip') ? -2.5 : 2.5, duration: 2.4 + Math.random() * .6, ease: 'sine.inOut', yoyo: true, repeat: -1 });
			var blob = $('.pitem__blob', card);
			if (blob) gsap.to(blob, { scale: 1.08, rotate: 20, duration: 3.2, ease: 'sine.inOut', yoyo: true, repeat: -1 });
			gsap.from($$('.pitem__text > *', card), { y: 30, opacity: 0, duration: .8, stagger: .06, ease: 'expo.out', scrollTrigger: { trigger: card, start: 'top 75%', once: true } });
		});
	}

	// 섹션 스냅: 섹션이 화면을 채우면 멈추고(그동안 애니메이션 재생), 스크롤 한 번(트랙패드 관성 포함) = 한 칸
	// 영상 → 맛 라인업 → 상품 제목 → 상품 카드들 → 디바이스 까지. 그 아래는 보통 스크롤.
	function snapSections() {
		if (!finePointer || reduce) return; // 터치 기기는 기본 스크롤
		var points = [];
		function docTop(el) { return el.getBoundingClientRect().top + window.scrollY; }
		function measure() {
			var pts = [];
			pts.push(0); // 맨 위 (경고 바 포함)
			$$('.film, .row, #device').forEach(function (el) { var t = Math.round(docTop(el)); if (t > 120) pts.push(t); });
			var cards = $$('.pitem');
			if (cards.length) {
				var wrap = cards[0].parentNode;
				var gap = parseFloat(getComputedStyle(wrap).rowGap) || 0;
				var y = docTop(wrap);
				cards.forEach(function (c) {
					pts.push(Math.round(y - (parseFloat(getComputedStyle(c).top) || 0)));
					y += c.offsetHeight + gap;
				});
			}
			points = pts.sort(function (a, b) { return a - b; }).filter(function (v, i, arr) { return !i || v - arr[i - 1] > 40; });
		}
		measure();
		if (points.length < 2) return;
		window.addEventListener('resize', measure);
		ST.addEventListener('refresh', measure);

		var busy = false, held = false, freeAt = 0, lastAbs = 0, lastT = 0;
		var HOLD = 500; // 섹션에 멈춘 뒤 다음 스크롤을 받기까지 (ms)
		var GAP = 220;  // 이만큼 스크롤이 멈췄다가 다시 굴리면 '새 스크롤'
		function first() { return points[0]; }
		function last() { return points[points.length - 1]; }
		function target(dir) {
			var y = window.scrollY, i;
			if (dir > 0) { for (i = 0; i < points.length; i++) if (points[i] > y + 4) return points[i]; }
			else { for (i = points.length - 1; i >= 0; i--) if (points[i] < y - 4) return points[i]; }
			return null;
		}
		function go(y) {
			busy = true;
			freeAt = Infinity;
			var done = function () { busy = false; freeAt = Date.now() + HOLD; };
			if (lenis) lenis.scrollTo(y, { duration: .45, easing: function (t) { return 1 - Math.pow(1 - t, 3); }, lock: true, force: true, onComplete: done });
			else { window.scrollTo({ top: y, behavior: 'smooth' }); setTimeout(done, 450); }
		}
		window.addEventListener('wheel', function (e) {
			if (body.classList.contains('is-locked') || body.classList.contains('nav-open')) return;
			var dir = e.deltaY > 0 ? 1 : (e.deltaY < 0 ? -1 : 0);
			if (!dir) return;
			var y = window.scrollY, abs = Math.abs(e.deltaY), now = Date.now();
			var gap = now - lastT;
			lastT = now;
			// 다음 칸은 (1) 이동이 끝나고 0.3초가 지난 뒤에만, 그리고 (2) 손을 멈췄다 다시 굴렸거나 새로 세게 굴렸을 때만
			// → 마우스 휠을 한 번 '드르륵' 굴리거나 트랙패드 관성이 남아 있어도 한 칸만 이동
			if (held && !busy && now >= freeAt && (gap > GAP || abs > lastAbs * 1.3 + 2)) held = false;
			lastAbs = abs;
			// 아래로: 마지막 지점 전까지 / 위로: 마지막 섹션(디바이스) 안에서부터
			var inside = dir > 0 ? (y < last() - 4) : (y > first() + 4 && y <= last() + window.innerHeight * .9);
			if (!(busy || held || inside)) return;
			e.preventDefault();
			e.stopImmediatePropagation();
			if (busy || held || now < freeAt) return;
			var to = target(dir);
			if (to === null) return;
			held = true;
			go(to);
		}, { passive: false, capture: true });
	}

	/* -------------------------------------------------------------- Flavors */
	function flavors() {
		var cards = $$('.card');
		if (!cards.length) return;

		gsap.from(cards, {
			y: 80, opacity: 0, duration: 1, stagger: { each: .05, grid: 'auto', from: 'start' }, ease: 'expo.out',
			scrollTrigger: { trigger: '.grid', start: 'top 85%' }
		});

		$$('.chip').forEach(function (chip) {
			chip.addEventListener('click', function () {
				$$('.chip').forEach(function (c) { c.classList.toggle('is-active', c === chip); });
				var f = chip.dataset.filter;
				gsap.to(cards, {
					opacity: 0, y: 20, duration: .25, stagger: .015, ease: 'power2.in', onComplete: function () {
						var shown = cards.filter(function (c) {
							var on = f === 'all' || c.dataset.cat === f;
							c.classList.toggle('is-hidden', !on);
							return on;
						});
						gsap.fromTo(shown, { opacity: 0, y: 40, scale: .95 }, { opacity: 1, y: 0, scale: 1, duration: .7, stagger: .04, ease: 'expo.out' });
						ST.refresh();
					}
				});
			});
		});

		// 틸트 + 컬러 채움 시작점
		cards.forEach(function (card) {
			var a = $('a', card);
			a.addEventListener('pointerenter', function (e) { setOrigin(e); });
			a.addEventListener('pointerleave', function (e) {
				setOrigin(e);
				gsap.to(a, { rotationX: 0, rotationY: 0, duration: .8, ease: 'elastic.out(1, .5)' });
			});
			if (finePointer && !reduce) {
				a.addEventListener('pointermove', function (e) {
					var r = a.getBoundingClientRect();
					var px = (e.clientX - r.left) / r.width - .5;
					var py = (e.clientY - r.top) / r.height - .5;
					gsap.to(a, { rotationY: px * 14, rotationX: -py * 14, duration: .5, ease: 'power3' });
				});
			}
			function setOrigin(e) {
				var r = a.getBoundingClientRect();
				a.style.setProperty('--mx', ((e.clientX - r.left) / r.width * 100) + '%');
				a.style.setProperty('--my', ((e.clientY - r.top) / r.height * 100) + '%');
			}
		});
	}

	/* --------------------------------------------------------------- Device */
	// 스크롤을 붙잡지 않음: 들어올 때 한 번 등장하고, 화면에 보이는 동안 맛이 저절로 바뀜
	function device() {
		var root = $('#device');
		if (!root) return;
		var imgs = $$('.device__stack img', root);
		gsap.timeline({ scrollTrigger: { trigger: root, start: 'top 40%', once: true } })
			.from($$('.device__title .line > span', root), { yPercent: 110, stagger: .1, duration: .9, ease: 'expo.out' }, 0)
			.from($('.device__stack', root), { scale: .6, rotate: -25, y: 120, opacity: 0, duration: 1.2, ease: 'expo.out' }, .1)
			.from($$('.callout', root), { opacity: 0, x: function (i) { return i % 2 ? 50 : -50; }, stagger: .12, duration: .8, ease: 'expo.out' }, .4);
		// 둥실 떠 있는 느낌 (이미지가 하나여도 움직임)
		gsap.to($('.device__float', root) || imgs[0].parentNode, { y: -16, rotate: 3, duration: 2.6, ease: 'sine.inOut', yoyo: true, repeat: -1 });
		if (imgs.length < 2 || !root.querySelector('.device__stack.is-cycle')) return;
		var cur = 0, timer = null;
		var fan = root.querySelector('.device__stack.is-fan');
		// 3개가 나란히: 가운데 크게, 양옆은 작게 기울여서 — 2.2초마다 한 칸씩 돌아감
		function layout(instant) {
			var n = imgs.length;
			imgs.forEach(function (img, i) {
				var k = (i - cur + n) % n;
				var p = k === 0 ? { xPercent: 0, rotate: 0, scale: 1, opacity: 1, zIndex: 3 }
					: k === 1 ? { xPercent: 92, rotate: 14, scale: .78, opacity: .9, zIndex: 2 }
					: k === n - 1 ? { xPercent: -92, rotate: -14, scale: .78, opacity: .9, zIndex: 2 }
					: { xPercent: k < n / 2 ? 140 : -140, rotate: 0, scale: .5, opacity: 0, zIndex: 1 };
				p.duration = instant ? 0 : .9;
				p.ease = 'expo.inOut';
				p.overwrite = 'auto';
				gsap.to(img, p);
			});
			gsap.to(root, { '--c1': imgs[cur].dataset.c1, '--c2': imgs[cur].dataset.c2, duration: instant ? 0 : .9 });
		}
		if (fan) layout(true);
		function next() {
			if (fan) { cur = (cur + 1) % imgs.length; layout(false); return; }
			var a = imgs[cur];
			cur = (cur + 1) % imgs.length;
			var b = imgs[cur];
			gsap.to(a, { opacity: 0, rotate: 12, duration: .7, ease: 'power2.inOut' });
			gsap.fromTo(b, { opacity: 0, rotate: -12 }, { opacity: 1, rotate: 0, duration: .7, ease: 'power2.inOut' });
			gsap.to(root, { '--c1': b.dataset.c1, '--c2': b.dataset.c2, duration: .7 });
		}
		ST.create({
			trigger: root, start: 'top bottom', end: 'bottom top',
			onToggle: function (s) { clearInterval(timer); if (s.isActive) timer = setInterval(next, 2200); }
		});
	}

	/* ------------------------------------------------------------------ CTA */
	function cta() {
		var root = $('#wholesale');
		if (!root) return;
		var imgs = $$('.cta__fan img', root);
		gsap.fromTo(imgs,
			{ rotate: 0, x: 0, y: 80 },
			{
				rotate: function (i, el) { return +getComputedStyle(el).getPropertyValue('--o') * 11; },
				x: function (i, el) { return +getComputedStyle(el).getPropertyValue('--o') * Math.min(60, window.innerWidth / 18); },
				y: function (i, el) { return Math.abs(+getComputedStyle(el).getPropertyValue('--o')) * 14; },
				ease: 'none',
				scrollTrigger: { trigger: root, start: 'top 80%', end: 'center center', scrub: 1 }
			});
		var title = $('[data-fill]', root);
		gsap.fromTo(title, { '--fill': '0%' }, { '--fill': '100%', ease: 'none', scrollTrigger: { trigger: title, start: 'top 85%', end: 'bottom 45%', scrub: true } });
	}

	/* ------------------------------------------------ 스펙 글자 칸에 맞추기 */
	// 값이 칸보다 길면(예: Disposable) 같은 줄의 스펙 글자를 함께 조금씩 줄임 — 원래 크기보다 커지지는 않음
	function fitSpecs() {
		$$('.spdp__specs, .pinfo__specs').forEach(function (group) {
			var dds = $$('dd', group);
			if (!dds.length) return;
			dds.forEach(function (d) { d.style.fontSize = ''; });
			var base = parseFloat(getComputedStyle(dds[0]).fontSize), size = base;
			var range = document.createRange();
			var fits = function () {
				return dds.every(function (d) { range.selectNodeContents(d); return range.getBoundingClientRect().width <= d.clientWidth - 10; }); // 오른쪽 여백 10px 이상
			};
			while (!fits() && size > 12) {
				size -= 1;
				dds.forEach(function (d) { d.style.fontSize = size + 'px'; });
			}
		});
	}
	fitSpecs();
	window.addEventListener('resize', fitSpecs);
	if (document.fonts && document.fonts.ready) document.fonts.ready.then(fitSpecs);

	/* --------------------------------------------------------- 공통 리빌 */
	function reveals() {
		$$('[data-reveal]').forEach(function (el) {
			gsap.from($$('.line > span', el), { yPercent: 110, duration: 1.1, stagger: .1, ease: 'expo.out', scrollTrigger: { trigger: el, start: 'top 85%' } });
		});
		// 숫자 카운트 (회사 소개 / 스펙)
		$$('[data-count]').forEach(function (el) {
			var end = parseFloat(el.dataset.count);
			if (isNaN(end)) return;
			var suffix = el.textContent.replace(/^[\d.,\s]+/, '');
			var o = { v: 0 };
			gsap.to(o, {
				v: end, duration: 1.6, ease: 'power3.out',
				scrollTrigger: { trigger: el, start: 'top 90%', once: true },
				onUpdate: function () { el.textContent = Math.round(o.v) + suffix; }
			});
		});

		// 서브 페이지 제목
		if ($('.page-head')) gsap.from('.page-head__title .ch', { yPercent: 100, opacity: 0, stagger: .025, duration: 1, ease: 'expo.out', delay: .2 });

		// 상세 페이지
		if ($('.pdp')) {
			gsap.from('.pdp__device > *', { y: 200, rotate: 25, opacity: 0, duration: 1.4, ease: 'elastic.out(1, .7)' });
			gsap.from('.pdp__name .ch', { yPercent: 100, opacity: 0, stagger: .03, duration: 1, ease: 'expo.out' });
			gsap.from('.pdp__copy > *', { y: 40, opacity: 0, stagger: .08, duration: 1, ease: 'expo.out', delay: .2 });
		}
	}

	/* ------------------------------------------------------ Film (intro) */
	function film() {
		var root = $('#top');
		if (!root) return;
		var video = $('video', root);
		var btn = $('.film__sound', root);
		if (video && btn) {
			btn.addEventListener('click', function () {
				video.muted = !video.muted;
				btn.setAttribute('aria-pressed', String(!video.muted));
				btn.textContent = video.muted ? 'Sound off' : 'Sound on';
			});
		}
		// 화면 밖에서는 영상 정지
		if (video) ST.create({ trigger: root, start: 'top bottom', end: 'bottom top', onToggle: function (s) { s.isActive ? video.play().catch(function () {}) : video.pause(); } });
	}
	function filmIntro() {
		if (!$('#top')) return;
		gsap.from('.film__bar > *', { y: 24, opacity: 0, duration: .9, stagger: .08, ease: 'expo.out' });
		gsap.from('.film__media--empty img', { y: 200, rotate: 20, opacity: 0, duration: 1.4, ease: 'elastic.out(1, .7)' });
	}

	/* ------------------------------------------- Flavour line-up + About */
	function about() {
		var row = $('#row');
		if (!row) return;
		var viewport = $('.row__viewport', row);
		var track = $('.row__track', row);
		var mains = $$('.row__item.is-main', row);
		var clones = $$('.row__item.is-clone', row);
		var n = mains.length;
		var st = { gap: 0, m: 0, speed: 0, run: false };
		var itemW = function () { return mains[0].offsetWidth || 60; };
		var tight = function () { return -itemW() * .45; };                   // 촘촘하게 붙어 서 있는 간격
		var loose = function () { return Math.min(90, Math.max(28, itemW() * .9)); }; // 펼쳐진 간격
		st.gap = tight();

		// 매 프레임: 간격 적용 + 가운데 정렬 + 왼쪽으로 흐르기(무한 반복)
		function layout() {
			var setW = n * (itemW() + st.gap);
			var base = (viewport.clientWidth - (setW - st.gap)) / 2 - setW;
			var m = ((st.m % setW) + setW) % setW;
			track.style.setProperty('--gap', st.gap + 'px');
			gsap.set(track, { x: base - m });
		}
		gsap.ticker.add(function (t, dt) {
			if (st.run) st.m += st.speed * dt / 1000;
			layout();
		});

		// 화면에 들어와 멈추면 한 번 재생: 일자로 선 채 내려옴 → 쫙 펼쳐짐 → 파스텔 원 → 소개 글 → 왼쪽으로 흐름
		// (스크롤 위치에 묶지 않아서 위로 올라가도 되감기지 않음)
		var blooms = $$('.bloom', row);
		gsap.set(track, { y: function () { return -window.innerHeight * .7; }, opacity: 0 });
		gsap.set(clones, { opacity: 0 });
		gsap.set(blooms, { scale: 0, opacity: 0 });
		gsap.set($$('.about__intro > *', row), { y: 40, opacity: 0 });
		gsap.timeline({ paused: true, scrollTrigger: { trigger: row, start: 'top 70%', once: true, onEnter: function (self) { self.animation.play(); } } })
			.to(track, { y: 0, opacity: 1, duration: .7, ease: 'power3.out' }, 0)
			.fromTo(st, { gap: function () { return tight(); } }, { gap: function () { return loose(); }, duration: .8, ease: 'power3.inOut' }, .5)
			.to(blooms, { scale: 1, opacity: .95, duration: .8, ease: 'back.out(2.4)', stagger: { each: .04, from: 'random' } }, .6)
			.to(clones, { opacity: 1, duration: .4 }, 1)
			.to($$('.about__intro > *', row), { y: 0, opacity: 1, duration: .6, stagger: .06, ease: 'power2.out' }, .8)
			.add(function () { st.run = true; gsap.to(st, { speed: 42, duration: 1 }); }, 1.2);

		// 호버하면 멈춤 (맛 이름은 CSS 로 표시)
		viewport.addEventListener('pointerenter', function () { gsap.to(st, { speed: 0, duration: .5, overwrite: 'auto' }); });
		viewport.addEventListener('pointerleave', function () { if (st.run) gsap.to(st, { speed: 42, duration: .8, overwrite: 'auto' }); });

		blooms.forEach(function (b, i) {
			gsap.to(b, { xPercent: gsap.utils.random(-12, 12), yPercent: gsap.utils.random(-12, 12), duration: 4 + i % 4, ease: 'sine.inOut', yoyo: true, repeat: -1 });
		});

		// 펼쳐진 뒤 살짝 물결치듯
		$$('.row__item img', row).forEach(function (img, i) {
			gsap.to(img, { y: -8, duration: 1.8, ease: 'sine.inOut', yoyo: true, repeat: -1, delay: (i % n) * .12 });
		});
	}

	/* ------------------------------------------------------ Benefits/Steps */
	function blocks() {
		if ($('.benefits__list')) {
			gsap.from('.benefit', { y: 80, opacity: 0, rotate: function (i) { return i % 2 ? 3 : -3; }, stagger: .08, duration: 1, ease: 'expo.out', scrollTrigger: { trigger: '.benefits__list', start: 'top 85%' } });
		}
		$$('.steps').forEach(function (sec) {
			gsap.fromTo($('.steps__line i', sec), { scaleX: 0 }, { scaleX: 1, ease: 'none', scrollTrigger: { trigger: $('.steps__track', sec), start: 'top 75%', end: 'bottom 55%', scrub: true } });
			gsap.from($$('.step', sec), { y: 50, opacity: 0, stagger: .15, duration: .9, ease: 'expo.out', scrollTrigger: { trigger: $('.steps__track', sec), start: 'top 80%' } });
		});
		$$('.faq__item').forEach(function (d) {
			// 아코디언: 하나만 열기
			d.addEventListener('toggle', function () {
				if (d.open) $$('.faq__item').forEach(function (o) { if (o !== d) o.open = false; });
				ST.refresh();
			});
		});
	}

	/* ------------------------------------------------------------------ Run */
	var h = hero();
	if (!reduce) {
		film();
		about();
		lineup();
		snapSections();
		flavors();
		device();
		blocks();
		cta();
		reveals();
	}
	if (reduce) {
		flavors();
	}
	ST.sort();

	ageGate()
		.then(loader)
		.then(function () {
			body.classList.remove('is-loading');
			h.intro();
			filmIntro();
			ST.refresh();
		});

	window.addEventListener('load', function () { ST.refresh(); });
})();
